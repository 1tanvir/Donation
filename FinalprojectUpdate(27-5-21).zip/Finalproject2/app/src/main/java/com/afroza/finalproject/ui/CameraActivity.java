package com.afroza.finalproject.ui;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.media.FaceDetector;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.OrientationEventListener;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LifecycleOwner;


import com.afroza.finalproject.R;
import com.afroza.finalproject.model.User;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.networktask.UserApis;
import com.afroza.finalproject.utils.LoginHelper;
import com.google.common.util.concurrent.ListenableFuture;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;

public class CameraActivity extends BaseActivity {
    private PreviewView previewView;
    private ListenableFuture<ProcessCameraProvider> cameraProviderFuture;
    private TextView textView;
    private Executor executor;
    private ExecutorService executorService;

    private AppCompatImageButton btn;
    Uri cUri;
    private AlertDialog alertDialog;
    private AlertDialog.Builder abuilder;
    ProgressBar matchp;
    ProgressDialog progressDialog;
    ProgressDialog progressDialog1;
    private ProcessCameraProvider cameraProvider;
    private Preview preview;
    private ImageView imageView;
    private int Camera_permission_code=222;
    ImageCapture imageCapture1;
    private static final int CAMERA_REQUEST_CODE_CUSTOM = 778;

    private FaceDetector faceDetector;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        progressDialog = new ProgressDialog(this);
        progressDialog1 = new ProgressDialog(this);
        abuilder=new AlertDialog.Builder(this);


        executorService= Executors.newSingleThreadExecutor();
                executor= ContextCompat.getMainExecutor(this);
        previewView = findViewById(R.id.previewView);
        btn=findViewById(R.id.capbtn);
        imageView=findViewById(R.id.cpimg);
        cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        textView = findViewById(R.id.orientation);
        ImageCapture.Builder builder = new ImageCapture.Builder();
        final ImageCapture imageCapture = builder
                .setTargetRotation(this.getWindowManager().getDefaultDisplay().getRotation())
                .build();

        imageCapture1=imageCapture;

        if (allPermissionsGranted()) {
            startCamera(imageCapture);
        } else {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA}, Camera_permission_code);

        }


btn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if (allPermissionsGranted()) {
            //cameraProvider.unbind(preview);
            showProgressDialogWithTitle1("", "Taking Photo...");
            try {
                imageCapture.takePicture(executor,
                        new ImageCapture.OnImageCapturedCallback() {

                            @Override
                            public void onCaptureSuccess(@NonNull ImageProxy image) {
                                //super.onCaptureSuccess(image);
                                File f = ImageProxyToFile(image, CameraActivity.this);
                                hideProgressDialogWithTitle1();
                                //showProgressDialogWithTitle("","uploading...");
//Intent intent=new Intent();
//intent.
//                            setResult(,f);
                                //String imgstr=base64stringfromBitmap()
                                uploadImage(f);
                                image.close();
//
//
                            }

                            @Override
                            public void onError(@NonNull ImageCaptureException exception) {
                                hideProgressDialogWithTitle();
                                hideProgressDialogWithTitle1();

                                super.onError(exception);
                            }

                        });
                //hideProgressDialogWithTitle1();

            } catch (Exception ex) {
                String msg = ex.getMessage();
                hideProgressDialogWithTitle();
                hideProgressDialogWithTitle1();
            }
        }
        else {
            ActivityCompat.requestPermissions(CameraActivity.this, new String[] {Manifest.permission.CAMERA}, Camera_permission_code);

        }
    }
});

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == Camera_permission_code){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                startCamera(imageCapture1);
            }else {
                Toast.makeText(this, "Camera Permission is Required to Use camera.", Toast.LENGTH_SHORT).show();

            }
        }
    }

    private void startCamera(ImageCapture imageCapture) {
        cameraProviderFuture.addListener(new Runnable() {
            @Override
            public void run() {
                try {
                    cameraProvider = cameraProviderFuture.get();
                    //cameraProvider.unbindAll();
                    bindImageAnalysis(cameraProvider,imageCapture);
                } catch (ExecutionException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }, executor);
    }

    private boolean allPermissionsGranted() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED)
        {
            return true;
        }
        else
        {
return false;
        }
    }

//    private void setUpCameraX() {
//        CameraX.unbindAll();
//        val displayMetrics = DisplayMetrics().also { cameraView.display.getRealMetrics(it) }
//        val screenSize = Size(displayMetrics.widthPixels, displayMetrics.heightPixels)
//        val aspectRatio = Rational(displayMetrics.widthPixels, displayMetrics.heightPixels)
//        val rotation = cameraView.display.rotation
//    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
    private String base64imageFromFile(File f)
    {

        FileInputStream fis = null;
        try{
            fis = new FileInputStream(f);
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }
        Bitmap bm = BitmapFactory.decodeStream(fis);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG,100,baos);
        byte[] b = baos.toByteArray();
        String encImage = Base64.encodeToString(b, Base64.DEFAULT);
        //Base64.de
        return encImage;
    }
    private void uploadImage(File f) {
        Uri uri = Uri.fromFile(f);
        Bitmap bitmap;
        String base64imagestr="";
                try {
                    if (android.os.Build.VERSION.SDK_INT >= 29){
                        // To handle deprication use
                        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
                      bitmap = ImageDecoder.decodeBitmap(source);
                    } else{
                        // Use older version
                        bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    }

                    Bitmap thumbnail = ThumbnailUtils.extractThumbnail(bitmap, 96, 96); // if you mind scaling
                    FileOutputStream fileOutputStream = new FileOutputStream(f);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bitmap is required image which have to send  in Bitmap form
                    byte[] byteArray = baos.toByteArray();

                     base64imagestr = Base64.encodeToString(byteArray, Base64.DEFAULT);

                }
                catch (Exception e)
                {

                }

        int user_id= LoginHelper.getCurrentUser()!=null?LoginHelper.getCurrentUser().getUser_id():0;

        if(user_id==0)return;
        Retrofit retrofit = NetworkClient.getRetrofit();
showProgressDialogWithTitle("","Uploading.......");
        //RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);
//        double thresv =Double.parseDouble(PreferenceManager.getDefaultSharedPreferences(CameraActivity.this).getString("threshold", "0.25"));
//        if(thresv==0 )
//            thresv=0.25;
        //RequestBody thresbody = RequestBody.create(MediaType.parse("text/plain"), thresv);

//        String filename=file.getName();
//        String fileabspath=file.getAbsolutePath();
//        MultipartBody.Part parts = MultipartBody.Part.createFormData("image", file.getName(), requestBody);

        //RequestBody userid = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(user_id));

        UserApis userApis = retrofit.create(UserApis.class);
        //base64image= "data:image/jpg;base64,"+base64image;
        Call<String> call = userApis.uploadImage(base64imagestr,user_id);
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, retrofit2.Response<String> response) {
                String res=response.body();
                try {
                    hideProgressDialogWithTitle();

                    if(!res.contains("failed"))
                    {
                        //Uri mUri=cUri;


                        User user=LoginHelper.getCurrentUser();
                        user.setUser_image(res);
                        LoginHelper.setCurrentUser(user);
                        setResult(RESULT_OK);
                        finish();
                        //user.setUser_image(res);
                       // loadDefaultImage();

                    }
                    else
                    {

                        hideProgressDialogWithTitle();
//                                                           //Toast.makeText(MainActivity.this,"Match Found",Toast.LENGTH_LONG).show();
                    }
                    //Log.d("response_xx",msg);

                } catch (Exception e) {
                    hideProgressDialogWithTitle();

                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                checkInternetWithException(t);
                hideProgressDialogWithTitle();
//                builder.setMessage("Uploading Failed")
//                        .setCancelable(false)
//                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                alertDialog.dismiss();
//
//                            }
//                        });
//                alertDialog = builder.create();
//                alertDialog.setTitle("Failed");
//                alertDialog.show();
            }
        });
    }
//    private void uploadImage(File file) {
//
//        //File file = new File(filePath);
//        final Bitmap myBitmap;
//
//         if(file.exists()) {
//
//             myBitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
////             imageView.setImageBitmap(myBitmap);
////             imageView.setVisibility(View.VISIBLE);
////             previewView.setVisibility(View.GONE);
//         }
//         else
//             myBitmap=null;
//        Retrofit retrofit = NetworkClient.getRetrofit();
//
//        RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);
//        double thresv = Double.parseDouble(PreferenceManager.getDefaultSharedPreferences(com.fountainit.getmein.CameraActivity.this).getString("threshold", "0.25"));
//        if(thresv==0 )
//            thresv=0.25;
//        //RequestBody thresbody = RequestBody.create(MediaType.parse("text/plain"), thresv);
//
//        String filename=file.getName();
//        String fileabspath=file.getAbsolutePath();
//        MultipartBody.Part parts = MultipartBody.Part.createFormData("image", file.getName(), requestBody);
//
//        //RequestBody someData = RequestBody.create(MediaType.parse("text/plain"), "This is a new Image");
//
//        UploadApis uploadApis = retrofit.create(UploadApis.class);
//
//        Call<MatchResponse> call = uploadApis.uploadImage(parts,thresv);
//        call.enqueue(new Callback<MatchResponse>() {
//            @Override
//            public void onResponse(Call<MatchResponse> call, retrofit2.Response<MatchResponse> response) {
//                MatchResponse res=response.body();
//                try {
//                    hideProgressDialogWithTitle();
//
//
//                        //ImageView myImage = (ImageView) findViewById(R.id.imageviewTest);
//
//                        //mainBitmap=myBitmap;
//
//                   // }
//                                    //JSONObject jsonObject=new JSONObject(String.valueOf(response));
//                                    String msg=res.message;
//                                    String thres=res.thres;
//                                    Bitmap b=null;
//                                    if(msg.contains("No"))
//                                    {
//                                        //Uri mUri=cUri;
//
//                                        hideProgressDialogWithTitle();
//
//                                        abuilder.setMessage("There is no match")
//
//                                                .setCancelable(false)
//                                                .setPositiveButton("Register", new DialogInterface.OnClickListener() {
//                                                    @Override
//                                                    public void onClick(DialogInterface dialogInterface, int i) {
//                                                        try {
//                                                            Intent intent = new Intent(com.fountainit.getmein.CameraActivity.this, RegActivity.class);
//                                                            intent.putExtra("filepath",file.getAbsolutePath());
//                                                            try {
//                                                                startActivity(intent);
//                                                            }
//                                                            catch (Exception e)
//                                                            {
//
//                                                            }
//                                                        }
//                                                        catch (Exception e)
//                                                        {
//                                                            Log.d("latest error1::",e.getMessage());
//                                                        }
//
//                                                    }
//
//                                                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                                            @Override
//                                            public void onClick(DialogInterface dialogInterface, int i) {
//                                                alertDialog.dismiss();
//                                            }
//                                        });
//                                        alertDialog = abuilder.create();
//                                        alertDialog.setTitle("No Match");
//                                        alertDialog.show();
//                                    }
//                                    else
//                                    {
//
//                                        hideProgressDialogWithTitle();
//                                        String name=res.name;
//                                        String email=res.email;
//                                        String mobile=res.mobile;
//                                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
//                                            abuilder.setMessage(Html.fromHtml("<b>"+"Are you?"+"</b>"+"<br> Name:  <b>"+name+"</b><br> Email:  <b>"+email+"</b><br> Mobile:  <b>"+mobile+"</b>", Html.FROM_HTML_MODE_LEGACY));
//                                        } else {
//                                            //@Suppress("DEPRECATION")
//                                            try{
//                                            abuilder.setMessage(Html.fromHtml("<b>"+"Are you?"+"</b>"+"<br> Name:  <b>"+name+"</b><br> Email:  <b>"+email+"</b><br> Mobile:  <b>"+mobile+"</b>"));
//                                            }
//                                            catch (Exception ex)
//                                            {
//                                                abuilder.setMessage("Are you?"+"\n\n"+" Name:  "+name+"\n\n Email:  "+email+"\n\n Mobile:  "+mobile);
//
//                                            }
//
//                                        }
//                                        //abuilder.setMessage();
//
//                                                abuilder.setCancelable(false)
//                                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                                                    @Override
//                                                    public void onClick(DialogInterface dialogInterface, int i) {
//                                                        alertDialog.dismiss();
//
//                                                    }
//
//                                                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
//                                            @Override
//                                            public void onClick(DialogInterface dialogInterface, int i) {
//                                                try {
//                                                    Intent intent = new Intent(com.fountainit.getmein.CameraActivity.this, FindMeActivity.class);
//                                                    intent.putExtra("filepath",file.getAbsolutePath());
//                                                    startActivity(intent);
//                                                }
//                                                catch (Exception e)
//                                                {
//                                                    Log.d("latest error1::",e.getMessage());
//                                                }
//                                            }
//                                        });
//                                        alertDialog = abuilder.create();
//                                        alertDialog.setTitle("Match Found");
//                                        alertDialog.show();
////                                        String filepath=file.getAbsolutePath();
////
////                                        String name=res.name;
////                                        String email=res.email;
////                                        String mobile=res.mobile;
////                                        Intent intent = new Intent(CameraActivity.this, FaceResult.class);
////                                        intent.putExtra("ismatch",1);
////                                        intent.putExtra("thresval",thres);
////                                        intent.putExtra("filepath",file.getAbsolutePath());
////
////                                        //intent.putExtra("BitmapImage",myBitmap);
////                                        intent.putExtra("name",name);
////                                        intent.putExtra("email",email);
////                                        intent.putExtra("mobile",mobile);
////                                        try {
////                                            startActivity(intent);
////                                        }
////                                        catch (Exception e)
////                                        {
////                                            Log.d("latest error1::",e.getMessage());
////                                        }                                        //Toast.makeText(MainActivity.this,"Match Found",Toast.LENGTH_LONG).show();
//                                    }
//                                    Log.d("response_xx",msg);
//
//                                } catch (Exception e) {
//                                    hideProgressDialogWithTitle();
//                                    abuilder.setMessage("Detect Error \n Matching Exception")
//                                            .setCancelable(false)
//                                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                                                @Override
//                                                public void onClick(DialogInterface dialogInterface, int i) {
//                                                    alertDialog.dismiss();
//
//                                                }
//                                            });
//                                    alertDialog = abuilder.create();
//                                    alertDialog.setTitle("Failed");
//                                    alertDialog.show();
//                                    e.printStackTrace();
//                                }
//
//            }
//
//            @Override
//            public void onFailure(Call<MatchResponse> call, Throwable t) {
//                hideProgressDialogWithTitle();
//                abuilder.setMessage("Detect Error \n Timeout")
//                        .setCancelable(false)
//                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                alertDialog.dismiss();
//
//                            }
//                        });
//                alertDialog = abuilder.create();
//                alertDialog.setTitle("Failed");
//                alertDialog.show();
//            }
//        });
//    }



    public File ImageProxyToFile(ImageProxy image, Context context)
    {
        Bitmap bitmap=imageProxyToBitmap(image);
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

        File f = new File(context.getCacheDir(), "FaceDImage_"+timeStamp+".jpg");
        try {
            f.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

//Convert bitmap to byte array
       // Bitmap bitmap = bitmap;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100  , bos);
        byte[] bitmapdata = bos.toByteArray();

//write the bytes in file
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(f);
            fos.write(bitmapdata);
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }
    public String base64stringfromBitmap(Bitmap bitmap)
    {
        //ImageView iv1 = (ImageView)findViewById(R.id.imageView1);
        //BitmapDrawable drawable = (BitmapDrawable) iv.getDrawable();
        //Bitmap bitmap = drawable.getBitmap();
        //int wid=bitmap.getWidth();
        //int hei=bitmap.getHeight();
        // mainbitmap=bitmap;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] bb1 = bos.toByteArray();
        //int s=bb1.length;
        bitmap.compress(Bitmap.CompressFormat.JPEG,50,bos);
        //wid=bitmap.getWidth();
        //hei=bitmap.getHeight();
        byte[] bb = bos.toByteArray();
        //   s=bb.length;

        String imagestr = Base64.encodeToString(bb,0);
        return imagestr;
    }
    private void showProgressDialogWithTitle(String title, String substring) {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);
        //Setting Title
        progressDialog.setTitle(title);
        progressDialog.setMessage(substring);
        progressDialog.show();

    }
    private void showProgressDialogWithTitle1(String title, String substring) {
        progressDialog1.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog1.setCancelable(true);
        //Setting Title
        progressDialog1.setTitle(title);
        progressDialog1.setMessage(substring);
        progressDialog1.show();

    }

    // Method to hide/ dismiss Progress bar
    private void hideProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.dismiss();
    }
    private void hideProgressDialogWithTitle1() {
        progressDialog1.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog1.dismiss();
    }
    private void bindImageAnalysis(@NonNull ProcessCameraProvider cameraProvider, ImageCapture imageCapture) {
        ImageAnalysis imageAnalysis =
                new ImageAnalysis.Builder()
                        //.setTargetResolution(new Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
        imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this), new ImageAnalysis.Analyzer() {
            @Override
            public void analyze(@NonNull ImageProxy image) {
                image.close();
            }
        });
        OrientationEventListener orientationEventListener = new OrientationEventListener(this) {
            @Override
            public void onOrientationChanged(int orientation) {
                textView.setText(Integer.toString(orientation));
            }
        };
        orientationEventListener.enable();
        //ImageAnalysis imageAnalysis = new ImageAnalysis.Builder().build();


        //preview.setSurfaceProvider(mPreviewView.createSurfaceProvider());
        //cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis, imageCapture);

         preview = new Preview.Builder().build();
        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_FRONT).build();
        preview.setSurfaceProvider(previewView.createSurfaceProvider());
        cameraProvider.unbindAll();
        cameraProvider.bindToLifecycle((LifecycleOwner) this, cameraSelector,imageAnalysis, preview,imageCapture);

//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });


//        imageCapture.takePicture(this, new ImageCapture.OnImageCapturedCallback() {
//            @Override
//            public void onCaptureSuccess(@NonNull ImageProxy image) {
////                Bitmap bitmap = getBitmap(image);
////                InputImage inputImage = InputImage.fromBitmap(bitmap, image.getImageInfo().getRotationDegrees());
////                FaceDetector.Face result = detector.process(inputImage);
//            }
//        });
    }

    /**
     *  convert image proxy to bitmap
     *  @param image
     */
    private Bitmap mainBitmap;
    private Bitmap imageProxyToBitmap(ImageProxy image) {
        ByteBuffer buffer = image.getPlanes()[0].getBuffer();
        byte[] bytes = new byte[buffer.remaining()];
        buffer.get(bytes);
        Bitmap bitmap= BitmapFactory.decodeByteArray(bytes,0,bytes.length,null);
        mainBitmap=bitmap;
        return bitmap;
    }

}
