package com.afroza.finalproject.interfaces;

public interface ValidUserListener {
    void isUserValid(boolean isValid);
}
