package com.afroza.finalproject.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.ResultReceiver;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.afroza.finalproject.R;
import com.afroza.finalproject.model.Category;
import com.afroza.finalproject.model.CategoryType;
import com.afroza.finalproject.model.DonateInfo;
import com.afroza.finalproject.model.HttpResponse;
import com.afroza.finalproject.networktask.GeneralApis;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.utils.LoginHelper;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class CategoryDetails extends BaseActivity implements PopupMenu.OnMenuItemClickListener {
    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 2;
    EditText etTitle,etDesc,etName,etLocation,etDate,etTime,etQty;
    String etTitlestr,etDescstr,etNamestr,etLocationstr,etDatestr,etTimestr,etQtystr,typestr;
    int typeid=0,categoryid=0;
    List<CategoryType> categoryTypes;
    private LocationCallback locationCallback;
    private Location currentLocation;
    DatePickerDialog datePickerDialog;
    TimePickerDialog timePickerDialog;
    TextView typeName,detailName;
    Category category;
    AppCompatSpinner spnTypes;
    Toolbar toolbar;
    private ProgressDialog progressDialog;
    private AlertDialog alertDialog;
    private AlertDialog.Builder abuilder;
    ImageView editPhoto;

    public  final int CAMERA_REQUEST_CODE = 102;
    public  final int GALLERY_REQUEST_CODE = 105;
    Button saveBtn;
    CheckBox chkHideMobile,chkHideName;
    int chkHideMobileValue=0,chkHideNameValue=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.category_details);
        progressDialog = new ProgressDialog(this);
        abuilder=new AlertDialog.Builder(this);
        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        saveBtn=findViewById(R.id.saveBtn);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData();
            }
        });
        chkHideMobile=findViewById(R.id.chkHideMobile);
        chkHideName=findViewById(R.id.chkHideName);
        chkHideMobile.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                    chkHideMobileValue=1;
                else
                    chkHideMobileValue=0;
            }
        });
        chkHideName.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                    chkHideNameValue=1;
                else
                    chkHideNameValue=0;
            }
        });
        etTitle=findViewById(R.id.etTitle);
        etTime=findViewById(R.id.etTime);
        etDesc=findViewById(R.id.etDesc);
        etName=findViewById(R.id.etName);
        etQty=findViewById(R.id.etQty);
        spnTypes=findViewById(R.id.spnClothType);
        typeName=findViewById(R.id.typeName);
        detailName=findViewById(R.id.detailName);
        etLocation=findViewById(R.id.etPickup);
        etDate=findViewById(R.id.etdate);
        editPhoto=findViewById(R.id.editPhoto);
        editPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu=new PopupMenu(CategoryDetails.this,view);
                MenuInflater inflater=popupMenu.getMenuInflater();
                popupMenu.setOnMenuItemClickListener(CategoryDetails.this);
                inflater.inflate(R.menu.context_menu,popupMenu.getMenu());
                popupMenu.show();
            }
        });
        spnTypes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                CategoryType categoryType=categoryTypes.get(i);
                typestr=categoryType.getType_name();
                typeid=categoryType.getType_id();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        if(getIntent().getExtras()!=null)
        {
            try{

                String categoryinfo=getIntent().getStringExtra("categoryinfo");
                Gson gson=new Gson();
                category=gson.fromJson(categoryinfo,Category.class);
                categoryid=category.getCategory_id();
                setValues();
                loadList();
                //categoryTypes=category.getCatgory_type();
            }
            catch (Exception e)
            {}
        }
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // calender class's instance and get current date , month and year from calender
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR); // current year
                int mMonth = c.get(Calendar.MONTH); // current month
                int mDay = c.get(Calendar.DAY_OF_MONTH); // current day
                // date picker dialog
                datePickerDialog = new DatePickerDialog(CategoryDetails.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // set day of month , month and year value in the edit text
                                etDate.setText(dayOfMonth + "/"
                                        + (monthOfYear + 1) + "/" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.setTitle("Select Date");
                datePickerDialog.show();
            }
        });
        etTime.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(CategoryDetails.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        etTime.setText( selectedHour + ":" + selectedMinute);
                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();

            }
        });

//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            return;
//        }
//        locationCallback = new LocationCallback() {
//            @Override
//            public void onLocationResult(LocationResult locationResult) {
//                currentLocation = locationResult.getLocations().get(0);
//                getAddress(currentLocation);
//            };
//        };
//        startLocationUpdates();
//        fusedLocationClient.getLastLocation()
//                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
//                    @Override
//                    public void onSuccess(Location location) {
//                        // Got last known location. In some rare situations this can be null.
//                        if (location != null) {
//                            Geocoder geocoder;
//                            List<Address> addresses;
//                            geocoder = new Geocoder(ClothDetails.this, Locale.getDefault());
//
//                            try {
//                                addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
//                                String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
//                                String city = addresses.get(0).getLocality();
//                                String state = addresses.get(0).getAdminArea();
//                                String country = addresses.get(0).getCountryName();
//                                String postalCode = addresses.get(0).getPostalCode();
//                                String knownName = addresses.get(0).getFeatureName();
//
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }
//
//
//                            // Logic to handle location object
//                        }
//                    }
//                });
    }

    @SuppressWarnings("MissingPermission")
    private void startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            LocationRequest locationRequest = new LocationRequest();
            locationRequest.setInterval(2000);
            locationRequest.setFastestInterval(1000);
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

            fusedLocationClient.requestLocationUpdates(locationRequest,
                    locationCallback,
                    null);
        }
    }

    private void loadList()
    {
        int category_id= category.getCategory_id();
        Retrofit retrofit = NetworkClient.getRetrofit();
        GeneralApis generalApis = retrofit.create(GeneralApis.class);

        Call<JsonObject> call = generalApis.loadTypes(category_id);
        // Call<JsonArray> call = casesApis.getCases();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject res=response.body();
                try {


                    if(response.code()==200)
                    {
                        JsonArray types=res.getAsJsonArray("types");

                        Gson gson=new Gson();
                        CategoryType[] categoryTypeList=gson.fromJson(types,CategoryType[].class);
                       categoryTypes= Arrays.asList(categoryTypeList);
                        setSpinner();



                    }
                    else
                    {
//
                    }
                    //Log.d("response_xx",message);

                } catch (Exception e) {
                    //hideProgressDialogWithTitle();
                    try {
                        String reserr = e.getMessage();



                    } catch (Exception ex) {

                    }
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                String err=t.getLocalizedMessage();


            }
        });
    }
    @SuppressWarnings("MissingPermission")
    private void getAddress(Location location) {

        if (!Geocoder.isPresent()) {
//            Toast.makeText(AddressListActivity.this,
//                    "Can't find current address, ",
//                    Toast.LENGTH_SHORT).show();
            return;
        }
        Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(CategoryDetails.this, Locale.getDefault());

        try {
            addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
            etLocation.setText(address);
            String city = addresses.get(0).getLocality();
            String state = addresses.get(0).getAdminArea();
            String country = addresses.get(0).getCountryName();
            String postalCode = addresses.get(0).getPostalCode();
            String knownName = addresses.get(0).getFeatureName();

        } catch (IOException e) {
            e.printStackTrace();
        }
       // Intent intent = new Intent(this, GetAddressIntentService.class);
       // intent.putExtra("add_receiver", addressResultReceiver);
        //intent.putExtra("add_location", currentLocation);
        //startService(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startLocationUpdates();
                } else {
                    Toast.makeText(this, "Location permission not granted, " +
                                    "restart the app if you want the feature",
                            Toast.LENGTH_SHORT).show();
                }
                return;
            }

        }
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_gallery:
                try {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    //startActivityForResult(gallery, GALLERY_REQUEST_CODE);
                    //Intent intent=new Intent();
                    intent.setType("image/*");
                    //intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(intent, GALLERY_REQUEST_CODE);
                }
                catch (Exception ex)
                {

                }
                return true;
            case R.id.nav_camera:
                try {
                    Intent intent=new Intent(CategoryDetails.this, CameraActivity.class);
                    startActivityForResult(intent,CAMERA_REQUEST_CODE);
                }
                catch (Exception ex)
                {
                    String err=ex.getMessage();
                }
                return true;
            default:
                return false;
        }
    }

    private class LocationAddressResultReceiver extends ResultReceiver {
        LocationAddressResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {

            if (resultCode == 0) {
                //Last Location can be null for various reasons
                //for example the api is called first time
                //so retry till location is set
                //since intent service runs on background thread, it doesn't block main thread
                Log.d("Address", "Location null retrying");
                getAddress(currentLocation);
            }

            if (resultCode == 1) {
//                Toast.makeText(AddressListActivity.this,
//                        "Address not found, " ,
//                        Toast.LENGTH_SHORT).show();
            }

            String currentAdd = resultData.getString("address_result");

            showResults(currentAdd);
        }
    }

    private void showResults(String currentAdd){
        //currentAddTv.setText(currentAdd);
    }


    @Override
    protected void onResume() {
        super.onResume();
        //startLocationUpdates();
    }

//    @Override
//    protected void onPause() {
//        super.onPause();
//        fusedLocationClient.removeLocationUpdates(locationCallback);
//    }

    private void setSpinner()
    {
       // categoryTypes.add(0,new CategoryType(0,0,"Select Type"));
        ArrayAdapter<CategoryType> adapter =
            new ArrayAdapter<CategoryType>(getApplicationContext(),  android.R.layout.simple_spinner_dropdown_item, categoryTypes);
    adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);

    spnTypes.setAdapter(adapter);
    }
private void setValues()
{

    typeName.setText(category.getCategory_name()+" Type");
    detailName.setText(category.getCategory_name()+" Name");

//
}
private boolean getValues()
{
    boolean isvalid=true;
    if(TextUtils.isEmpty(etTitle.getText()))
    {
        isvalid=false;
        etTitle.setError("Input title");
    }
    else
    {

        etTitle.setError(null);
    }
    if(TextUtils.isEmpty(etLocation.getText()))
    {
        isvalid=false;
        etLocation.setError("Input Location");

    }
    else
    {

        etLocation.setError(null);
    }
    if(TextUtils.isEmpty(etDate.getText()))
    {
        isvalid=false;
        etDate.setError("Input Date");
    }
    else
    {

        etDate.setError(null);
    }
    if(TextUtils.isEmpty(etTime.getText()))
    {
        isvalid=false;
        etTime.setError("Input Time");
    }
    else
    {

        etTime.setError(null);
    }
    if(!isvalid)
        return false;
    try{
    etTitlestr=etTitle.getText().toString();
    etLocationstr=etLocation.getText().toString();
    etDatestr=etDate.getText().toString();
    etTimestr=etTime.getText().toString();
    etDescstr=etDesc.getText().toString();
    etQtystr=etQty.getText().toString();
    etNamestr=etName.getText().toString();
    }
    catch (Exception e)
    {
        String error=e.getLocalizedMessage();
    }
   return true;


}
    private void saveData()
    {
        if(!getValues())
            return;
        int user_id=0;
        try{
            user_id= LoginHelper.getCurrentUser().getUser_id();
        }
        catch (Exception e)
        {

        }
        if(user_id==0)return;

        try{
            checkInternet();
        }
        catch (Exception ees)
        {

        }
showProgressDialogWithTitle("","Saving data....");
        Retrofit retrofit = NetworkClient.getRetrofit();

        GeneralApis generalApis = retrofit.create(GeneralApis.class);

        Call<JsonObject> call = generalApis.saveDonate(
                user_id,
                categoryid,
                typeid,
                etTitlestr,
                etLocationstr,
                etDatestr,
                etTimestr,
                etNamestr,
                etDescstr,
                etQtystr,
                chkHideMobileValue,
                chkHideNameValue
        );
        // Call<JsonArray> call = casesApis.getCases();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject res=response.body();
                try {
                    hideProgressDialogWithTitle();

                    //if(res.size()==0)

                    if(response.code()==200)
                    {
                        Gson gson=new Gson();
                        HttpResponse httpResponse= gson.fromJson(res,HttpResponse.class);
                        String message=httpResponse.getMessage();
                        if(httpResponse.getMessage().contains("success"))
                        {
                            abuilder.setMessage("Your Donate info saved Successfully")
                                    .setCancelable(false)
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            alertDialog.dismiss();
                                            onBackPressed();
                                        }
                                    })
                                    ;
                            alertDialog=abuilder.create();
                            alertDialog.setTitle("Success");
                            alertDialog.show();
                        }
                        else {
                            abuilder.setMessage(message)
                                    .setCancelable(false)
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            alertDialog.dismiss();
                                        }
                                    });
                            alertDialog = abuilder.create();
                            alertDialog.setTitle("Failed");
                            alertDialog.show();
                        }


                    }
                    else
                    {
                        abuilder.setMessage("Saving failed")
                                .setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        alertDialog.dismiss();
                                    }
                                });
                        alertDialog=abuilder.create();
                        alertDialog.setTitle("Failed");
                        alertDialog.show();
                        //btnUpload.setVisibility(View.VISIBLE);
//Toast.makeText(MainActivity.this,"Match Found",Toast.LENGTH_LONG).show();
                    }
                    //Log.d("response_xx",message);

                } catch (Exception e) {
                    hideProgressDialogWithTitle();
                    try {
                        String reserr = e.getMessage();

                        // btnUpload.setVisibility(View.VISIBLE);
                        //loading.setVisibility(View.GONE);
//                        abuilder.setMessage("Register Failed \n"+reserr)
//                                .setCancelable(false)
//                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialogInterface, int i) {
//                                        alertDialog.dismiss();
//
//                                    }
//                                });
//                        alertDialog = abuilder.create();
//                        alertDialog.setTitle("Failed");
//                        alertDialog.show();
                        //btnUpload.setVisibility(View.VISIBLE);

                        // Toast.makeText(RegActivity.this, res, Toast.LENGTH_LONG).show();

                    } catch (Exception ex) {

                    }
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                try{
                    checkInternetWithException(t);
                }
                catch (Exception ees)
                {

                }
                hideProgressDialogWithTitle();
                abuilder.setMessage("Error \n HTTP Exception "+t.getLocalizedMessage())
                        .setCancelable(false)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                alertDialog.dismiss();

                            }
                        });
                alertDialog = abuilder.create();
                alertDialog.setTitle("Failed");
                alertDialog.show();


            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //overridePendingTransition(R.anim.trans_left_in,R.anim.trans_left_out);
        overridePendingTransition(R.anim.trans_right_in,R.anim.trans_right_out);
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;

    }
    private void showProgressDialogWithTitle(String title,String substring) {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);
        //Setting Title
        progressDialog.setTitle(title);
        progressDialog.setMessage(substring);
        progressDialog.show();

    }

    // Method to hide/ dismiss Progress bar
    private void hideProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.dismiss();
    }
}