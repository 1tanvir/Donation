package com.afroza.finalproject.ui;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;

import com.afroza.finalproject.R;
import com.afroza.finalproject.model.RegistrationResponse;
import com.afroza.finalproject.model.UpdateProfileResponse;
import com.afroza.finalproject.model.User;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.networktask.UserApis;
import com.afroza.finalproject.utils.LoginHelper;
import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;

public class PasswordChangeActivity extends BaseActivity {

    TextInputEditText etOldPass,etNewPass,etRePass;
    String oldpassStr,newpassStr,repassStr;
    ProgressDialog progressDialog;
    private AlertDialog alertDialog;
    private AlertDialog.Builder builder;
    Button btnSave;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_change);
        toolbar=findViewById(R.id.toolBar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("");
        etOldPass=findViewById(R.id.etOldPass);
        etNewPass=findViewById(R.id.etPass);
        etRePass=findViewById(R.id.etRepass);
        btnSave=findViewById(R.id.accSave);
        progressDialog = new ProgressDialog(this);
        builder=new AlertDialog.Builder(this);
        //setValues();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateProfile();
            }
        });

    }

//    private void setValues() {
//        try {
//            Bundle bundle = getIntent().getExtras();
//            etName.setText(bundle.getString("name"));
//            etEmail.setText(bundle.getString("email"));
//            etMobile.setText(bundle.getString("mobile"));
//        }
//        catch (Exception e)
//        {}
//    }
    private boolean getValues()
    {
        boolean valid=true;
        try{
            if(TextUtils.isEmpty(etOldPass.getText()))
            {
                etOldPass.setError("Insert old password");
                valid=false;
                return valid;
            }
            else
            {
                etOldPass.setError(null);
                oldpassStr=etOldPass.getText().toString();
            }
            if(TextUtils.isEmpty(etNewPass.getText()))
            {
                etNewPass.setError("Insert new password");
                valid=false;
                return valid;
            }
            else
            {
                etNewPass.setError(null);
                newpassStr=etNewPass.getText().toString();
            }
            if(TextUtils.isEmpty(etRePass.getText()))
            {
                etRePass.setError("Insert new password again");
                valid=false;
                return valid;
            }
            else
            {
                if(etNewPass.getText().toString().equals(etRePass.getText().toString())) {
                    etRePass.setError(null);
                    repassStr = etRePass.getText().toString();
                }
                else
                {
                    etRePass.setError("Password does not match");
                    valid=false;
                    return valid;
                }
            }
        }
        catch (Exception e)
        {
         valid=false;
        }
        return valid;
    }
    private void showProgressDialogWithTitle(String title, String substring) {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);
        //Setting Title
        progressDialog.setTitle(title);
        progressDialog.setMessage(substring);
        progressDialog.show();

    }

    // Method to hide/ dismiss Progress bar
    private void hideProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.dismiss();
    }
    private void updateProfile()
    {
        //User currentuser=LoginHelper.getCurrentUser();
        if (!getValues()) {

            return;
        }
        // assignValues();
        // final String usertoken=new RandomString(21).nextString();
        int user_id=0;
        try{
            user_id= LoginHelper.getCurrentUser().getUser_id();
        }
        catch (Exception e)
        {

        }
        if(user_id==0)return;
        showProgressDialogWithTitle("","Updating....");
        Retrofit retrofit = NetworkClient.getRetrofit();
        if(!networkReachAbilityCheck())
        {
            return;
        }
        UserApis userApis = retrofit.create(UserApis.class);

        Call<JsonObject> call = userApis.updatePassword(
                user_id,
                oldpassStr,
                newpassStr

        );
        // Call<JsonArray> call = casesApis.getCases();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                JsonObject res=response.body();
                try {
                    hideProgressDialogWithTitle();

                    //if(res.size()==0)

                    if(response.code()==200)
                    {
                        Gson gson=new Gson();
                        RegistrationResponse updateProfileResponse=gson.fromJson(res,RegistrationResponse.class);
                        String message=updateProfileResponse.getMessage();

                        if(message.contains("success"))
                        {

//                           User user=LoginHelper.getCurrentUser();
//                           user.setUser_name(nameStr);
//                           user.setUser_email(emailStr);
//                           user.setUser_mobile(mobileStr);
//                            SingleTonClass.getInstance().setCurrentuser(user);
//                            LoginHelper.setCurrentUser(user);

                           // onResume();

                            builder.setMessage("Updated Successful")
                                    .setCancelable(false)
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {

                                            alertDialog.dismiss();
                                            //onBackPressed();

                                        }
                                    });
                            alertDialog = builder.create();
                            alertDialog.setTitle("Update");

                            //alertDialog.show();
                        }
                        else
                        {
                            builder.setMessage(message)
                                    .setCancelable(false)
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {

                                            alertDialog.dismiss();

                                        }
                                    });
                            alertDialog = builder.create();
                            alertDialog.setTitle("Update failed");
                            alertDialog.show();
                        }
                    }
                    else
                    {
//
                        builder.setMessage("Update Failed")
                                .setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                        alertDialog.dismiss();

                                    }
                                });
                        alertDialog = builder.create();
                        alertDialog.setTitle("Update");
                        alertDialog.show();
                    }
                    //Log.d("response_xx",message);

                } catch (Exception e) {
                    hideProgressDialogWithTitle();
                    try {
                        String reserr = e.getMessage();
                        builder.setMessage("Update Failed")
                                .setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                        alertDialog.dismiss();

                                    }
                                });
                        alertDialog = builder.create();
                        alertDialog.setTitle("Update");
                        alertDialog.show();

                    } catch (Exception ex) {

                    }
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                checkInternetWithException(t);
                hideProgressDialogWithTitle();
                builder.setMessage("Update Failed")
                        .setCancelable(false)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                alertDialog.dismiss();

                            }
                        });
                alertDialog = builder.create();
                alertDialog.setTitle("Registration");
                alertDialog.show();
            }
        });
    }

}