package com.afroza.finalproject.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

@Keep
public class UserSettings {

    @SerializedName("issms")
    private int issms;
    @SerializedName("isemail")
    private int isemail;
    @SerializedName("country")
    private int country;
    @SerializedName("district")
    private int district;
    @SerializedName("thana")
    private int thana;
    @SerializedName("postal")
    private String postal;
    @SerializedName("address")
    private String address;
    @SerializedName("contact")
    private String contact;
    @SerializedName("legal")
    private String legal;

    public UserSettings() {
    }

    public UserSettings(int issms, int isemail, int country, int district, int thana, String postal, String address, String contact, String legal) {
        this.issms = issms;
        this.isemail = isemail;
        this.country = country;
        this.district = district;
        this.thana = thana;
        this.postal = postal;
        this.address = address;
        this.contact = contact;
        this.legal = legal;
    }

    public int getIssms() {
        return issms;
    }

    public void setIssms(int issms) {
        this.issms = issms;
    }

    public int getIsemail() {
        return isemail;
    }

    public void setIsemail(int isemail) {
        this.isemail = isemail;
    }

    public int getCountry() {
        return country;
    }

    public void setCountry(int country) {
        this.country = country;
    }

    public int getDistrict() {
        return district;
    }

    public void setDistrict(int district) {
        this.district = district;
    }

    public int getThana() {
        return thana;
    }

    public void setThana(int thana) {
        this.thana = thana;
    }

    public String getPostal() {
        return postal;
    }

    public void setPostal(String postal) {
        this.postal = postal;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getLegal() {
        return legal;
    }

    public void setLegal(String legal) {
        this.legal = legal;
    }

    @Override
    public String toString() {
        return "UserSettings{" +
                "issms=" + issms +
                ", isemail=" + isemail +
                ", country=" + country +
                ", district=" + district +
                ", thana=" + thana +
                ", postal=" + postal +
                ", address='" + address + '\'' +
                ", contact='" + contact + '\'' +
                ", legal='" + legal + '\'' +
                '}';
    }
}
