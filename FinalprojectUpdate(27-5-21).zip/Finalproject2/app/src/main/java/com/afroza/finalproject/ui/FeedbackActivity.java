package com.afroza.finalproject.ui;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import com.afroza.finalproject.R;
import com.afroza.finalproject.networktask.GeneralApis;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.utils.LoginHelper;
import com.google.android.material.textfield.TextInputEditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;

public class FeedbackActivity extends BaseActivity {
TextInputEditText title,body;
Button sendBtn;
    private ProgressDialog progressDialog;
    private AlertDialog alertDialog;
    private AlertDialog.Builder builder;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        progressDialog = new ProgressDialog(this);
        builder=new AlertDialog.Builder(this);
        toolbar=findViewById(R.id.toolBar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("");
        title=findViewById(R.id.titletext);
        body=findViewById(R.id.bodytext);
        sendBtn=findViewById(R.id.sendbtn);
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              sendData();
            }
        });

    }

    private void sendData()
    {
        int user_id= LoginHelper.getCurrentUser()!=null?LoginHelper.getCurrentUser().getUser_id():0;
        String user_name=LoginHelper.getCurrentUser()!=null?LoginHelper.getCurrentUser().getUser_name():"";
        if(user_id==0)return;
        //final String usertoken=new RandomString(21).nextString();

        showProgressDialogWithTitle("","Sending....");
        Retrofit retrofit = NetworkClient.getRetrofit();

        GeneralApis generalApis = retrofit.create(GeneralApis.class);
        String titletext=title.getText().toString();
        String bodytext=body.getText().toString();
        Call<String> call = generalApis.sendFeedback(user_name,titletext,bodytext);
        // Call<JsonArray> call = casesApis.getCases();
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, retrofit2.Response<String> response) {
                String res=response.body();
                try {
                    hideProgressDialogWithTitle();

                    //if(res.size()==0)

                    if(response.code()==200)
                    {

                        if(res.contains("success"))
                        {
                            builder.setMessage("Sent Successful")
                                    .setCancelable(false)
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            clearData();
                                            alertDialog.dismiss();
                                            onBackPressed();

                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            clearData();
                                            alertDialog.dismiss();


                                        }
                                    });
                            alertDialog = builder.create();
                            alertDialog.setTitle("Feedback");
                            alertDialog.show();
                        }
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//                            helptext.setText(Html.fromHtml(res, Html.FROM_HTML_MODE_COMPACT));
//                        } else {
//                            helptext.setText(Html.fromHtml(res));
//                        }

//                        allcases.clear();
//                        Gson gson=new Gson();
//                        CaseInfo[] allcaseinfos= gson.fromJson(res,CaseInfo[].class);
//                        List<CaseInfo> listCases = new ArrayList<>(Arrays.asList(allcaseinfos));
//
//                        if(allcaseinfos.length==0) {
//                            //casesAdapter.setState(casesAdapter.STATE_NORMAL);
//                            allcases.addAll(listCases);
//
//                        }
//                        else {
//                            //casesAdapter.setState(casesAdapter.STATE_NORMAL);
//
//                            allcases.addAll(listCases);
//                        }
//                        casesAdapter.notifyDataSetChanged();


//
                    }
                    else
                    {
//
                    }
                    //Log.d("response_xx",message);

                } catch (Exception e) {
                    hideProgressDialogWithTitle();
                    try {
                        String reserr = e.getMessage();


                    } catch (Exception ex) {

                    }
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                hideProgressDialogWithTitle();
                String err=t.getLocalizedMessage();

            }
        });
    }
    private void clearData()
    {
        title.setText("");
        body.setText("");
    }
    private void showProgressDialogWithTitle(String title,String substring) {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);
        //Setting Title
        progressDialog.setTitle(title);
        progressDialog.setMessage(substring);
        progressDialog.show();

    }

    // Method to hide/ dismiss Progress bar
    private void hideProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.dismiss();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //overridePendingTransition(R.anim.trans_left_in,R.anim.trans_left_out);
        overridePendingTransition(R.anim.trans_right_in,R.anim.trans_right_out);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;

    }
}