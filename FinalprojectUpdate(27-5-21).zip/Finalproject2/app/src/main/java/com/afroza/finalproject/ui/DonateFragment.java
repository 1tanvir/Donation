package com.afroza.finalproject.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.afroza.finalproject.R;
import com.afroza.finalproject.adapters.RVAdapter;
import com.afroza.finalproject.helper.AppHelper;
import com.afroza.finalproject.model.Category;
import com.afroza.finalproject.utils.AutoFitGridLayoutManager;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DonateFragment extends Fragment implements RVAdapter.OnRVClickListener {


    private RecyclerView recyclerView;
    private AutoFitGridLayoutManager autoFitGridLayoutManager;
    private RVAdapter rvAdapter;
    private List<Category> categories;
    public static DonateFragment newInstance() {
        DonateFragment fragment = new DonateFragment();
//
        return fragment;
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
        //final TextView textView = root.findViewById(R.id.text_dashboard);
//        dashboardViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        categories=new ArrayList<>();
        setCategories();
        recyclerView=root.findViewById(R.id.catRV);
        //autoFitGridLayoutManager=new AutoFitGridLayoutManager(getContext(),200);
        GridLayoutManager manager = new GridLayoutManager(getContext(), 2, GridLayoutManager.VERTICAL, false);
        //LinearLayoutManager manager1=new LinearLayoutManager(getContext());
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(manager);
        rvAdapter=new RVAdapter(getContext(),categories,this);
        recyclerView.setAdapter(rvAdapter);

        return root;
    }
    private void setCategories()
    {
        String categoriesSerial= AppHelper.getSharedPrefValue("categories");
        Gson gson=new Gson();
        Category[] categoryarr=gson.fromJson(categoriesSerial,Category[].class);
        List<Category> categoryList= Arrays.asList(categoryarr);
        categories.addAll(categoryList);
    }

    @Override
    public void onRVItemClick(int position) {
        try {
            Category category = categories.get(position);
            Intent intent = new Intent(getContext(), CategoryDetails.class);
            Gson gson=new Gson();
            String categorySerial=gson.toJson(category,Category.class);
            intent.putExtra("categoryinfo", categorySerial);
            getActivity().startActivityForResult(intent, 999);
        }
        catch (Exception e)
        {

        }
    }
}