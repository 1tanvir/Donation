package com.afroza.finalproject.ui;


import com.afroza.finalproject.model.DonateInfo;
import com.afroza.finalproject.model.User;

public class SingleTonClass {

    User currentuser;
    String userToken;
    String fcmToken;

String userAccessToken;
    DonateInfo donateInfo;


    boolean hasNewToken;

    private static final SingleTonClass newInstance = new SingleTonClass();
    public static SingleTonClass getInstance() {
        return newInstance;
    }
    private SingleTonClass() {
    }

    public String getUserToken() {
        return userToken;
    }

    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }

    public User getCurrentuser() {
        return currentuser;
    }

    public void setCurrentuser(User currentuser) {
        this.currentuser = currentuser;
    }






    public String getFcmToken() {
        return fcmToken;
    }

    public void setFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
    }

    public boolean isHasNewToken() {
        return hasNewToken;
    }

    public void setHasNewToken(boolean hasNewToken) {
        this.hasNewToken = hasNewToken;
    }





    public String getUserAccessToken() {
        return userAccessToken;
    }

    public void setUserAccessToken(String userAccessToken) {
        this.userAccessToken = userAccessToken;
    }

    public DonateInfo getDonateInfo() {
        return donateInfo;
    }

    public void setDonateInfo(DonateInfo donateInfo) {
        this.donateInfo = donateInfo;
    }
}