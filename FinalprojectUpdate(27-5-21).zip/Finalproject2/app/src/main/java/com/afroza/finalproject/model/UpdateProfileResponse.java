package com.afroza.finalproject.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Keep
public class UpdateProfileResponse implements Serializable {
    @SerializedName("message")
    private String message;
    @SerializedName("emailverified")
    private int email_verif;
    @SerializedName("mobileverified")
    private int mobile_verif;


    public UpdateProfileResponse() {
    }

    public UpdateProfileResponse(String message, int email_verif, int mobile_verif) {
        this.message = message;
        this.email_verif = email_verif;
        this.mobile_verif = mobile_verif;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getEmail_verif() {
        return email_verif;
    }

    public void setEmail_verif(int email_verif) {
        this.email_verif = email_verif;
    }

    public int getMobile_verif() {
        return mobile_verif;
    }

    public void setMobile_verif(int mobile_verif) {
        this.mobile_verif = mobile_verif;
    }

    @Override
    public String toString() {
        return "UpadateProfileResponse{" +
                "message='" + message + '\'' +
                ", email_verif=" + email_verif +
                ", mobile_verif=" + mobile_verif +
                '}';
    }
}
