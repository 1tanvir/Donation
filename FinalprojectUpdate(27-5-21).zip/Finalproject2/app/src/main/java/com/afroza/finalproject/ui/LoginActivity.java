package com.afroza.finalproject.ui;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;

import com.afroza.finalproject.R;
import com.afroza.finalproject.interfaces.ClickListenerM;
import com.afroza.finalproject.interfaces.CustomClickListener;
import com.afroza.finalproject.model.LoginResponse;
import com.afroza.finalproject.model.OtpResponse;
import com.afroza.finalproject.model.RegistrationResponse;
import com.afroza.finalproject.model.User;
import com.afroza.finalproject.networktask.FcmApis;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.networktask.StaticClass;
import com.afroza.finalproject.networktask.UserApis;
import com.afroza.finalproject.utils.LoginHelper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import static com.afroza.finalproject.networktask.StaticClass.SHAREPREF;


public class LoginActivity extends BaseActivity implements View.OnClickListener {

   // private LoginViewModel loginViewModel;
    private ProgressDialog progressDialog;
String username,password;
TextView signup,errortext,forgottv;
CheckBox remem;
ImageView regNewBtn;
    private AlertDialog alertDialog;
    private AlertDialog.Builder builder;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.M){
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        setContentView(R.layout.activity_login);
        errortext=findViewById(R.id.errorText);
        progressDialog = new ProgressDialog(this);
        builder=new AlertDialog.Builder(this);
        regNewBtn=findViewById(R.id.regNewBtn);
        regNewBtn.setOnClickListener(this);
        remem=findViewById(R.id.remembercheck);

        remem.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                {
                    try {
                        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(SHAREPREF, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        //editor.putString("name", "Elena");
                        editor.putString("login_username", username);
                        editor.putString("login_password", password);
                        editor.apply();
                    }
                    catch (Exception e)
                    {

                    }
                }
            }
        });
signup=findViewById(R.id.signuplink);
signup.setOnClickListener(this);


        final EditText usernameEditText = findViewById(R.id.editTextEmail);
        final EditText passwordEditText = findViewById(R.id.editTextPassword);
        final Button loginButton = findViewById(R.id.cirLoginButton);
        final ProgressBar loadingProgressBar = findViewById(R.id.loading);


        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                errortext.setVisibility(View.GONE);
                errortext.setText("");
                if(usernameEditText.getText().toString().trim().length()>0 && passwordEditText.getText().toString().trim().length()>0) {
                    loginButton.setEnabled(true);
//                    loginButton.setBackgroundColor(getResources().getColor(R.color.primary_color));
//                    loginButton.setTextColor(getResources().getColor(R.color.secondary_color));
                    username=usernameEditText.getText().toString().trim();
                    password=passwordEditText.getText().toString().trim();
                    remem.setEnabled(true);
                }
                else
                {
                    loginButton.setEnabled(false);
//                    loginButton.setBackgroundColor(getResources().getColor(R.color.button_inactive));
//                    loginButton.setTextColor(getResources().getColor(R.color.button_text_inactive));
                    remem.setEnabled(false);
                }

            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(usernameEditText.getText().toString().trim().length()>0 && passwordEditText.getText().toString().trim().length()>0)
                {
                    try {

                        checkLogin();
                    }
                    catch (Exception e)
                    {
                        errortext.setVisibility(View.VISIBLE);
                        errortext.setText("Login Failed");
                    }

                }

            }
        });
        try {
            SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(SHAREPREF, Context.MODE_PRIVATE);
            String login_username = sharedPreferences.getString("login_username", "");
            String login_password = sharedPreferences.getString("login_password", "");

            usernameEditText.setText(login_username);
            passwordEditText.setText(login_password);
        }
        catch (Exception e)
        {

        }
    }

    private void checkLogin()
    {
        if(!networkReachAbilityCheck())
        {
            return;
        }
        errortext.setVisibility(View.GONE);
        errortext.setText("");
        //final String usertoken= LoginHelper.getUniqueUserToken();

        showProgressDialogWithTitle("","Authenticating....");
        Retrofit retrofit = NetworkClient.getRetrofit();


        UserApis userApis = retrofit.create(UserApis.class);

        Call<JsonObject> call = userApis.checkLogin(username,password);
        // Call<JsonArray> call = casesApis.getCases();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject res=response.body();
                //errortext.setText(res.toString());

                try {
                    //hideProgressDialogWithTitle();

                    //if(res.size()==0)

                    if(response.code()==200)
                    {

                        Gson gson=new Gson();

                        LoginResponse userinfo= gson.fromJson(res,LoginResponse.class);
//
                        if(userinfo.getMessage().contains("success"))
                        {
                            User user=userinfo.getUser();
                            LoginHelper.setCurrentUser(user);
                              loginSuccess();
                              LoginHelper.setLoginSession(LoginActivity.this);
//
                        }
                        else
                        {
                            hideProgressDialogWithTitle();
                            errortext.setVisibility(View.VISIBLE);
                            errortext.setText("Login Failed");
                            Log.d("Login failed0: ",userinfo.getMessage());
                        }


                    }
                    else
                    {

                        hideProgressDialogWithTitle();
                        errortext.setVisibility(View.VISIBLE);
                        errortext.setText("Login Failed");
                        Log.d("Login failed1: ",response.code()+" "+response.errorBody().toString());
                    }
                    //Log.d("response_xx",message);

                } catch (Exception e) {
                    hideProgressDialogWithTitle();
                    try {
                        String reserr = e.getMessage();
                        errortext.setVisibility(View.VISIBLE);
                        errortext.setText("Login Failed");
                        Log.d("Login failed2: ",reserr);

                        //errortext.setText("Login Failed2: " +reserr);

                    } catch (Exception ex) {

                    }
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                try{
                    checkInternetWithException(t);
                }
                catch (Exception ees)
                {

                }

                hideProgressDialogWithTitle();
                errortext.setVisibility(View.VISIBLE);
                errortext.setText("Login Failed");
                Log.d("Login failed3: ",t.getLocalizedMessage());
            }
        });
    }

    private void loginSuccess()
    {
        if(LoginHelper.getCurrentUser()!=null) {
            int user_id=LoginHelper.getCurrentUser().getUser_id();
            if(!networkReachAbilityCheck())
            {
                return;
            }

            try {
                //sendFcmTokenToServer(user_id);
            } catch (Exception e) {
                //Log.d("FCM token save failed ", e.getLocalizedMessage());
            }

            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
//User user =new User();
//user.setuser_id(2);
//user.setUser_name("Md. Safiqul Islam");
//user.setUser_email("user@email.com");

            //errortext.setText("error6");
            startActivity((intent));
            //errortext.setText("error7");
            finish();
        }
    }





private void sendFcmTokenToServer(int user_id)
{
    String fcmtoken="";
    SharedPreferences sharedPreferences=getApplicationContext().getSharedPreferences(SHAREPREF, Context.MODE_PRIVATE);
    fcmtoken=sharedPreferences.getString("fcmtoken","");
    if(fcmtoken!=null && fcmtoken!="")
    {
     if(SingleTonClass.getInstance().isHasNewToken()) {
         saveFcmToken(user_id, fcmtoken);
     }
    }
    else
    {
//        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(new OnSuccessListener<String>() {
//            @Override
//            public void onSuccess(String s) {
//                SingleTonClass.getInstance().setFcmToken(s);
//
//                SharedPreferences sharedPreferences=getApplicationContext().getSharedPreferences(SHAREPREF, Context.MODE_PRIVATE);
//                SharedPreferences.Editor editor = sharedPreferences.edit();
//                //editor.putString("name", "Elena");
//                editor.putString("fcmtoken", s);
//                editor.apply();
//                saveFcmToken(user_id, s);
//            }
//        });
//        FirebaseInstallations.getInstance().getToken(true).addOnSuccessListener(new OnSuccessListener<InstallationTokenResult>() {
//            @Override
//            public void onSuccess(InstallationTokenResult installationTokenResult) {
//                String token =installationTokenResult.getToken();
//                SingleTonClass.getInstance().setFcmToken(token);
//                SharedPreferences sharedPreferences=getApplicationContext().getSharedPreferences(SHAREPREF, Context.MODE_PRIVATE);
//                SharedPreferences.Editor editor = sharedPreferences.edit();
//                //editor.putString("name", "Elena");
//                editor.putString("fcmtoken", token);
//                editor.apply();
//                saveFcmToken(user_id,token);
//            }
//        });
    }

    //int user_id= LoginHelper.getCurrentUser().getUser_id();

}
private void saveFcmToken(int user_id,String token)
{
     if(!networkReachAbilityCheck())
        {
            return;
        }

    Retrofit retrofit = NetworkClient.getRetrofit();
        checkInternet();
    FcmApis fcmApis = retrofit.create(FcmApis.class);
    Call<String> call = fcmApis.saveToken(user_id, token);
    call.enqueue(new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            String res=response.body();
            try {
                if(response.code()==200)
                {

                }
                else
                {
//
                }
                //Log.d("response_xx",message);

            } catch (Exception e) {

                try {
                    String reserr = e.getMessage();


                } catch (Exception ex) {

                }
                e.printStackTrace();
            }

        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            try{
                checkInternetWithException(t);
            }
            catch (Exception ees)
            {

            }
            String err=t.getLocalizedMessage();

        }
    });
}
    private void showProgressDialogWithTitle(String title,String substring) {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);
        //Setting Title
        progressDialog.setTitle(title);
        progressDialog.setMessage(substring);
        progressDialog.show();

    }

    // Method to hide/ dismiss Progress bar
    private void hideProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.dismiss();
    }

    @Override
    protected void onPause() {
        //progressDialog.dismiss();
        super.onPause();
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
        progressDialog.dismiss();
    }

    @Override
    public void onBackPressed() {
        this.moveTaskToBack(true);
    }






    @Override
    public void onClick(View view) {
        startActivity(new Intent(this, RegisterActivity.class));
        overridePendingTransition(R.anim.slide_in_right,R.anim.stay);
    }
}