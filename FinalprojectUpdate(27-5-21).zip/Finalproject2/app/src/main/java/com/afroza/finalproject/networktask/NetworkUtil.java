package com.afroza.finalproject.networktask;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;

public class NetworkUtil {
    public static boolean isNetworkConnected(Context context) {

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());
                return capabilities != null && (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
            } else {
                NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
                return activeNetwork != null && activeNetwork.isConnected();
            }
        }

        return false;
    }
//    public static boolean isNetworkConnected(Context context) {
//        final ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
//
//        if (cm != null) {
//            if (Build.VERSION.SDK_INT < 23) {
//                final NetworkInfo ni = cm.getActiveNetworkInfo();
//
//                if (ni != null) {
//                    return (ni.isConnected() && (ni.getType() == ConnectivityManager.TYPE_WIFI || ni.getType() == ConnectivityManager.TYPE_MOBILE));
//                }
//            } else {
//                final Network n = cm.getActiveNetwork();
//
//                if (n != null) {
//                    final NetworkCapabilities nc = cm.getNetworkCapabilities(n);
//
//                    return (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI));
//                }
//            }
//        }
//
//        return false;
//    }


    public static boolean getConnectivityStatus(Context context) {
        boolean status = false;
        ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null)

                status= true;
            else
                status= false;

        return status;
    }
    public static boolean getConnectivityStatusString(Context context) {
        boolean status = false;
        ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null) {
            if(internetIsConnected())
                status= true;
            else
                status= false;
//            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
//                status = 1;
//                return status;
//            } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
//                status = 1;
//                return status;
//            }
        } else {
            status=false;
            return false;
        }
       return status;
    }
    public static boolean internetIsConnected() {
        try {
            String command = "ping -c 1 google.com";
            return (Runtime.getRuntime().exec(command).waitFor() == 0);
        } catch (Exception e) {
            return false;
        }
    }
}
