package com.afroza.finalproject.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.afroza.finalproject.R;

public class FoodDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_details2);
    }
}