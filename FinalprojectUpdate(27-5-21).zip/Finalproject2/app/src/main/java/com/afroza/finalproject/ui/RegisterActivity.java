package com.afroza.finalproject.ui;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.afroza.finalproject.R;
import com.afroza.finalproject.model.RegistrationResponse;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.networktask.UserApis;
import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;


public class RegisterActivity extends BaseActivity implements View.OnClickListener {

ImageView loginNewBtn;
TextView loginlink;
TextInputEditText etName,etEmail,etMobile,etPassword,etRePassword;
String etNamestr,etEmailstr,etMobilestr,etPasswordstr,etRePasswordstr;
    private AlertDialog alertDialog;
    private AlertDialog.Builder builder;
    private ProgressDialog progressDialog;
    Button regBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        changeStatusBarColor();

        progressDialog = new ProgressDialog(this);
        builder=new AlertDialog.Builder(this);
        etName=findViewById(R.id.editTextName);
        etEmail=findViewById(R.id.editTextEmail);
        etMobile=findViewById(R.id.editTextMobile);
        etPassword=findViewById(R.id.editTextPassword);
        etRePassword=findViewById(R.id.editTextRePassword);
        loginNewBtn=findViewById(R.id.loginNewBtn);
        loginNewBtn.setOnClickListener(this);
        loginlink=findViewById(R.id.loginlink);
        loginlink.setOnClickListener(this);
        regBtn=findViewById(R.id.cirRegisterButton);
        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    register();
                }
                catch (Exception e)
                {

                }
            }
        });

    }
    private void changeStatusBarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//            window.setStatusBarColor(Color.TRANSPARENT);
            window.setStatusBarColor(getResources().getColor(R.color.register_bk_color));
        }
    }

    private boolean setValues()
    {
        boolean isvalid=true;
        if(TextUtils.isEmpty(etName.getText()))
        {
            isvalid=false;
            etName.setError("Input Name");
        }
        else
        {
            etName.setError(null);
            etNamestr=etName.getText().toString();

        }
        if(TextUtils.isEmpty(etEmail.getText()))
        {
            isvalid=false;
            etEmail.setError("Input Email");
        }
        else
        {
            etEmail.setError(null);
            etEmailstr=etEmail.getText().toString();

        }
        if(TextUtils.isEmpty(etPassword.getText()))
        {
            isvalid=false;
            etPassword.setError("Input Password");
        }
        else
        {

            if(etPassword.getText().toString().length()<6 || etPassword.getText().toString().length()>10)
            {
                isvalid=false;
                etPassword.setError("Password length should be between 6 to 10");
            }
            else
            {
                etPassword.setError(null);
                etPasswordstr=etPassword.getText().toString();
            }


        }

        if(TextUtils.isEmpty(etRePassword.getText()))
        {
            isvalid=false;
            etRePassword.setError("Input Confirm Password");
        }
        else {

            if (etRePassword.getText().toString().length() < 6 || etRePassword.getText().toString().length() > 10) {
                isvalid = false;
                etRePassword.setError("Password length should be between 6 to 10");
            } else {
                if (!etPassword.getText().toString().equals(etRePassword.getText().toString())) {
                    isvalid = false;
                    etRePassword.setError("Password and confirm password does not match");
                } else {
                    etRePassword.setError(null);
                    etRePasswordstr = etRePassword.getText().toString();
                }

            }
        }
            etMobilestr=etMobile.getText().toString();
            return isvalid;



    }


    private void showProgressDialogWithTitle(String title,String substring) {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);
        //Setting Title
        progressDialog.setTitle(title);
        progressDialog.setMessage(substring);
        progressDialog.show();

    }

    // Method to hide/ dismiss Progress bar
    private void hideProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.dismiss();
    }
    private void register()
    {
        if (!setValues())
        {
            return;
        }
        if(!networkReachAbilityCheck())
        {
            return;
        }

        // assignValues();
        // final String usertoken=new RandomString(21).nextString();

        showProgressDialogWithTitle("","Registering....");
        Retrofit retrofit = NetworkClient.getRetrofit();

        UserApis userApis = retrofit.create(UserApis.class);

        Call<JsonObject> call = userApis.register(
                etNamestr,
                etEmailstr,
                //lawyerid,
                //useremail,
                etMobilestr,
                // useraddress,
                etPasswordstr
        );
        // Call<JsonArray> call = casesApis.getCases();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                JsonObject res=response.body();
                try {
                    hideProgressDialogWithTitle();

                    //if(res.size()==0)

                    if(response.code()==200)
                    {
                        Gson gson=new Gson();
                        RegistrationResponse registrationResponse=gson.fromJson(res,RegistrationResponse.class);
                        String message=registrationResponse.getMessage();

                        if(message.contains("success"))
                        {
//                           int user_id=registrationResponse.getUser_id();
//                           CommonHelper.showInputAlertDialog(RegisterActivity.this, new CustomClickListener() {
//                               @Override
//                               public void onClick(String code) {
//                                   if(code.contains("resend"))
//                                       resendCode(user_id);
//                                   else
//                                        verifyAccount(user_id,code);
//                               }
//                           },new String[]{usermobile});

                            builder.setMessage("Registration Successful")
                                    .setCancelable(false)
                                    .setPositiveButton("Back to login", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {

                                            alertDialog.dismiss();
                                            onBackPressed();

                                        }
                                    });
                            alertDialog = builder.create();
                            alertDialog.setTitle("Registration");
                            alertDialog.show();
                        }
                        else
                        {
                            builder.setMessage(message)
                                    .setCancelable(false)
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {

                                            alertDialog.dismiss();

                                        }
                                    });
                            alertDialog = builder.create();
                            alertDialog.setTitle("Registration");
                            alertDialog.show();
                        }
                    }
                    else if(response.code()==401)
                    {
                        Gson gson=new Gson();
                        RegistrationResponse registrationResponse=gson.fromJson(res,RegistrationResponse.class);
                        String message=registrationResponse.getMessage();
//
                        builder.setMessage(message)
                                .setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                        alertDialog.dismiss();

                                    }
                                });
                        alertDialog = builder.create();
                        alertDialog.setTitle("Registration Failed");
                        alertDialog.show();
                    }
                    //Log.d("response_xx",message);

                } catch (Exception e) {
                    hideProgressDialogWithTitle();
                    try {
                        String reserr = e.getMessage();
                        builder.setMessage("Registration Failed")
                                .setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                        alertDialog.dismiss();

                                    }
                                });
                        alertDialog = builder.create();
                        alertDialog.setTitle("Registration");
                        alertDialog.show();

                    } catch (Exception ex) {

                    }
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                checkInternetWithException(t);
                hideProgressDialogWithTitle();
                builder.setMessage("Registration Failed")
                        .setCancelable(false)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                alertDialog.dismiss();

                            }
                        });
                alertDialog = builder.create();
                alertDialog.setTitle("Registration");
                alertDialog.show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //overridePendingTransition(R.anim.trans_left_in,R.anim.trans_left_out);
        overridePendingTransition(R.anim.trans_right_in,R.anim.trans_right_out);
    }
    @Override
    public void onClick(View view) {
        startActivity(new Intent(this, LoginActivity.class));
        overridePendingTransition(R.anim.slide_in_left,android.R.anim.slide_out_right);
    }
}
