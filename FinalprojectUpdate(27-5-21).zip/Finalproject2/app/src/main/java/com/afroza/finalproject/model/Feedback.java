package com.afroza.finalproject.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Keep
public class Feedback implements Serializable {
    @SerializedName("id")
    private int feedback_id;
    @SerializedName("feedback_title")
    private String feedback_title;
    @SerializedName("feedback")
    private String feedback_text;
    @SerializedName("created_by")
    private String feedback_by;
    @SerializedName("created_at")
    private String feedback_date;
    @SerializedName("response")
    private String feedback_response;
    public Feedback() {
    }

    public Feedback(int feedback_id, String feedback_title, String feedback_text, String feedback_by, String feedback_date, String feedback_response) {
        this.feedback_id = feedback_id;
        this.feedback_title = feedback_title;
        this.feedback_text = feedback_text;
        this.feedback_by = feedback_by;
        this.feedback_date = feedback_date;
        this.feedback_response = feedback_response;
    }

    public int getFeedback_id() {
        return feedback_id;
    }

    public void setFeedback_id(int feedback_id) {
        this.feedback_id = feedback_id;
    }

    public String getFeedback_title() {
        return feedback_title;
    }

    public void setFeedback_title(String feedback_title) {
        this.feedback_title = feedback_title;
    }

    public String getFeedback_text() {
        return feedback_text;
    }

    public void setFeedback_text(String feedback_text) {
        this.feedback_text = feedback_text;
    }

    public String getFeedback_by() {
        return feedback_by;
    }

    public void setFeedback_by(String feedback_by) {
        this.feedback_by = feedback_by;
    }

    public String getFeedback_date() {
        return feedback_date;
    }

    public void setFeedback_date(String feedback_date) {
        this.feedback_date = feedback_date;
    }

    public String getFeedback_response() {
        return feedback_response;
    }

    public void setFeedback_response(String feedback_response) {
        this.feedback_response = feedback_response;
    }

    @Override
    public String toString() {
        return "Feedback{" +
                "feedback_id=" + feedback_id +
                ", feedback_title='" + feedback_title + '\'' +
                ", feedback_text='" + feedback_text + '\'' +
                ", feedback_by='" + feedback_by + '\'' +
                ", feedback_date='" + feedback_date + '\'' +
                ", feedback_response='" + feedback_response + '\'' +
                '}';
    }
}
