package com.afroza.finalproject.networktask;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class NetworkClient {
    private static Retrofit retrofit;
    //private static final String BASE_URL = "http://192.168.31.118/";
    //private static final String BASE_URL = "http://192.168.88.21/";
    private static final String BASE_URL = StaticClass.BASE_URL;

    public static Retrofit getRetrofit() {
//        SharedPreferences sharedPreferences = DaanApplication.getAppContext().getSharedPreferences(StaticClass.SHAREPREF, Context.MODE_PRIVATE);
//final String token= sharedPreferences.getString("access_token","");
        OkHttpClient okHttpClient = new OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                //.addInterceptor(new ConnectivityInterceptor())
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request newRequest  = chain.request().newBuilder()
                                //.addHeader("x-access-token", token )
                                .build();
                        return chain.proceed(newRequest);
                    }
                })
                .build();
        if (retrofit == null) {
            retrofit = new Retrofit.Builder().baseUrl(BASE_URL).
                    addConverterFactory(GsonConverterFactory.create()).client(okHttpClient).build();
        }
        return retrofit;
    }
}
