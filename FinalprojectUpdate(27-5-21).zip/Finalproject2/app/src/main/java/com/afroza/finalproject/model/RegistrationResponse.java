package com.afroza.finalproject.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Keep
public class RegistrationResponse implements Serializable {
    @SerializedName("message")
    private String message;
    @SerializedName("user_id")
    private int user_id;



    public RegistrationResponse() {
    }

    public RegistrationResponse(String message, int user_id) {
        this.message = message;
        this.user_id = user_id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    @Override
    public String toString() {
        return "RegistrationResponse{" +
                "message='" + message + '\'' +
                ", user_id=" + user_id +
                '}';
    }
}
