package com.afroza.finalproject.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Keep
public class HttpResponse implements Serializable {
    @SerializedName("message")
    private String message;

    @SerializedName("statuscode")
    private int statuscode;


    public HttpResponse() {
    }

    public HttpResponse(String message, int statuscode) {
        this.message = message;
        this.statuscode = statuscode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getStatuscode() {
        return statuscode;
    }

    public void setStatuscode(int statuscode) {
        this.statuscode = statuscode;
    }

    @Override
    public String toString() {
        return "HttpResponse{" +
                "message='" + message + '\'' +
                ", statuscode=" + statuscode +
                '}';
    }
}
