package com.afroza.finalproject.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.IntDef;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.afroza.finalproject.R;
import com.afroza.finalproject.helper.AppHelper;
import com.afroza.finalproject.model.Feedback;
import com.github.marlonlom.utilities.timeago.TimeAgo;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;

public class FeedbackAdapter extends RecyclerView.Adapter<FeedbackAdapter.ViewHolder>  implements Filterable {
    private List<Feedback> notifications=new ArrayList<>();
    private List<Feedback> notificationsold=new ArrayList<>();

    private static final int VIEW_TYPE_EMPTY_LIST_PLACEHOLDER = 0;
    private static final int VIEW_TYPE_OBJECT_VIEW = 1;
    private  View vLoadingView;
    private  View vEmptyView;
    private  View vErrorView;

    @Override
    public Filter getFilter() {
        notifications=notificationsold;
        return new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults=new FilterResults();
                if(charSequence==null || charSequence.length()==0)
                {
                    filterResults.count=notificationsold.size();
                    filterResults.values=notificationsold;
                }
                else
                {
                    String searchstring=charSequence.toString().toLowerCase();
                    List<Feedback> searchcases=new ArrayList<>();
                    for (Feedback notificationInfo:
                            notifications) {
                        try {

                            if (    (notificationInfo.getFeedback_text()!=null &&
                                    notificationInfo.getFeedback_text().toLowerCase().contains(searchstring))
                                    ||
                                    (notificationInfo.getFeedback_response()!=null &&
                                            notificationInfo.getFeedback_response().toLowerCase().contains(searchstring))
                                    )
                            {
                                searchcases.add(notificationInfo);
                            }
                        }
                        catch (Exception e)
                        {
                            String err=e.getMessage();
                        }
                    }
                    filterResults.count=searchcases.size();
                    filterResults.values=searchcases;
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                notifications=(List<Feedback>)filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @IntDef({STATE_NORMAL, STATE_LOADING, STATE_EMPTY, STATE_ERROR})
    @Retention(RetentionPolicy.SOURCE)
    public @interface State {
    }
    public static final int STATE_NORMAL = 0;
    public static final int STATE_LOADING = 1;
    public static final int STATE_EMPTY = 2;
    public static final int STATE_ERROR = 3;

    public static final int TYPE_LOADING = 1000;
    public static final int TYPE_EMPTY = 1001;
    public static final int TYPE_ERROR = 1002;
    @State
    private int state = STATE_NORMAL;

    public FeedbackAdapter(List<Feedback> notifications
                           //  , View loadingView, View emptyView, View errorView
    ) {
        this.notifications = notifications;
        this.notificationsold = notifications;

//        this.vLoadingView = loadingView;
//        this.vEmptyView = emptyView;
//        this.vErrorView = errorView;
    }
    @State
    public int getState() {
        return state;
    }

    public void setState(@State int state) {
        this.state = state;
        //getWrappedAdapter().notifyDataSetChanged();
        notifyDataSetChanged();

    }




    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=null;

                view= LayoutInflater.from(parent.getContext()).inflate(R.layout.feedback_card_layout,parent,false);

//
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Feedback feedback = notifications.get(position);
            holder.fb_title.setText(feedback.getFeedback_title());
            holder.fb_body.setText(feedback.getFeedback_text());
            holder.fb_by.setText("by: "+feedback.getFeedback_by());

        long timeInMillis= AppHelper.milliseconds(feedback.getFeedback_date());
        String timeAgo = TimeAgo.using(timeInMillis+6*60*60*1000);

            holder.fb_date.setText(timeAgo);

               // holder.notif_date.setText(notificationInfo.getNotif_date());
               // String msg[]=notificationInfo.getNotif_message().split("\\|");
//        String title ="";
//        String body ="";
//                if(msg.length>1) {
//                     title = msg[0];
//                     body = msg[1];
//
//                }
//        holder.notif_title.setText(title);
//        holder.notif_body.setText(body);
//                break;
//        }

    }
    public void onBindErrorViewHolder(RecyclerView.ViewHolder holder, int position) {
    }

    public void onBindEmptyViewHolder(RecyclerView.ViewHolder holder, int position) {
    }

    public void onBindLoadingViewHolder(RecyclerView.ViewHolder holder, int position) {
    }
    @Override
    public int getItemCount() {
        switch (state) {
            case STATE_LOADING:
            case STATE_EMPTY:
            case STATE_ERROR:
                return 1;
        }
        return notifications.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView fb_date,fb_title,fb_body,fb_by;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

                fb_date = itemView.findViewById(R.id.tvDt);
                fb_title = itemView.findViewById(R.id.tvTitle);
                fb_body = itemView.findViewById(R.id.tvBody);
                fb_by = itemView.findViewById(R.id.tvBy);


        }


    }


//    @Override
//    public int getItemViewType(int position) {
//        switch (state) {
//            case STATE_LOADING:
//                return TYPE_LOADING;
//            case STATE_EMPTY:
//                return TYPE_EMPTY;
//            case STATE_ERROR:
//                return TYPE_ERROR;
//            default:
//                return super.getItemViewType(position);
//        }
//    }

//    @Override
//    public long getItemId(int position) {
//        if(notifications.size()>0)
//        return Integer.parseInt(notifications.get(position).getCase_id());
//        else
//            return 0;
//    }
}
