package com.afroza.finalproject.networktask;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface FcmApis {


    @FormUrlEncoded
    @POST("api/savetoken")
    Call<String> saveToken(
            @Field("user_id") int user_id,
            @Field("fcm_token") String fcm_token
    );
    @FormUrlEncoded
    @POST("api/savemessage")
    Call<String> saveMessage(
            @Field("user_id") int user_id,
            @Field("message_id") String message_id,
            @Field("message") String message
    );
}
