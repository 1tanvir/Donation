package com.afroza.finalproject.utils;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;


import com.afroza.finalproject.helper.DaanApplication;
import com.afroza.finalproject.interfaces.ValidUserListener;
import com.afroza.finalproject.model.LoginResponse;
import com.afroza.finalproject.model.User;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.networktask.UserApis;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;

public class LoginHelper {
    public static final String LOGINPREFERENCES = "CASEDIARYLOGINUSER" ;
    public static final String LOGINTOKEN = "logintoken";

    public static final String USER_ID = "user_id";
    public static final String USER = "userdata";
    public static final String USERLASTLOGIN = "lastlogin";
    public static SharedPreferences loginpref;
    private static ProgressDialog progressDialog;
    public static void setLoginSession(Context context)
    {
        if(LoginHelper.getCurrentUser()!=null) {
            User user = LoginHelper.getCurrentUser();
            loginpref=context.getSharedPreferences(LOGINPREFERENCES, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=loginpref.edit();
            editor.putInt(LOGINTOKEN,1);

            Gson gson=new Gson();
            String userdata=gson.toJson(user);
            editor.putString(USER,userdata);
            editor.apply();
        }
    }
    public static void clearLoginSession(Context context)
    {
        if(LoginHelper.getCurrentUser()!=null) {
            User user = LoginHelper.getCurrentUser();
            loginpref=context.getSharedPreferences(LOGINPREFERENCES, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=loginpref.edit();
            editor.clear();
            editor.apply();
        }
    }
    public static User getCurrentUser()
    {
       SharedPreferences pref= DaanApplication.getAppContext().getSharedPreferences(LOGINPREFERENCES, Context.MODE_PRIVATE);
        String userdata=loginpref.getString(USER,"");
        Gson gson=new Gson();
        try {
            User user = gson.fromJson(userdata, User.class);
            return user;
        }
        catch (Exception e)
        {}
        return null;
    }
    public static void setCurrentUser(User user)
    {
        SharedPreferences pref= DaanApplication.getAppContext().getSharedPreferences(LOGINPREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        Gson gson=new Gson();
        String userdata=gson.toJson(user);
        editor.putString(USER, userdata);
        editor.apply();

    }
    public static void checkUserLoginSession(Context context, ValidUserListener validUserListener)
    {
        loginpref=context.getSharedPreferences(LOGINPREFERENCES, Context.MODE_PRIVATE);
        if(loginpref.contains(LOGINTOKEN)) {
            int token = loginpref.getInt(LOGINTOKEN, 0);
            if(token==1)
            {
                String laslogin=loginpref.getString(USERLASTLOGIN,"");
                String userdata=loginpref.getString(USER,"");
                Gson gson=new Gson();
                User user=gson.fromJson(userdata,User.class);
                //SingleTonClass.getInstance().setCurrentuser(user);

                validUserListener.isUserValid(true);
            }
            else
                validUserListener.isUserValid(false);
            //int user_id = loginpref.getInt(USER_ID, 0);
            //checkLogin(user_id,token,context,validUserListener);
        }
        else
            validUserListener.isUserValid(false);

    }
    public static String getUniqueUserToken()
    {
        Long tsLong = System.currentTimeMillis()/1000;
        String ts = tsLong.toString();
        String usertoken="mbl_"+ts+"_"+new RandomString(128).nextString();
        return usertoken;
    }
    private static void showProgressDialogWithTitle(Context context,String title,String substring) {
        progressDialog = new ProgressDialog(context);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);
        //Setting Title
        progressDialog.setTitle(title);
        progressDialog.setMessage(substring);
        progressDialog.show();

    }

    // Method to hide/ dismiss Progress bar
    private static void hideProgressDialogWithTitle() {
        if(progressDialog!=null) {
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.dismiss();
        }
    }
    public static void checkLogin(int user_id,String usertoken,Context context,ValidUserListener validUserListener)
    {

        showProgressDialogWithTitle(context,"","Authenticating....");
        Retrofit retrofit = NetworkClient.getRetrofit();


        UserApis userApis = retrofit.create(UserApis.class);

        Call<JsonObject> call = userApis.isValid(user_id,usertoken);
        // Call<JsonArray> call = casesApis.getCases();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                JsonObject res=response.body();
                //errortext.setText(res.toString());

                try {
                    //hideProgressDialogWithTitle();

                    //if(res.size()==0)

                    if(response.code()==200)
                    {
                        Gson gson=new Gson();

                        LoginResponse userinfo= gson.fromJson(res,LoginResponse.class);
//
                        //errortext.setText(userinfo.toString());
                        String message=userinfo.getMessage();
                        //errortext.setText("error2: "+message);
                        if(userinfo.getMessage().contains("success"))
                        {
                            //errortext.setText("error2");

                            //SingleTonClass.getInstance().setUserToken(usertoken);
                            // errortext.setText("error3");
                            //errortext.setText("");
                            User user=userinfo.getUser();
                           // SingleTonClass.getInstance().setCurrentuser(user);
                            validUserListener.isUserValid(true);
//                            if(user.getMobileverified()==0)
//                            {
//                                try {
//                                    CommonHelper.showInputAlertDialog(LoginActivity.this, new CustomClickListener() {
//                                        @Override
//                                        public void onClick(String input) {
//                                            if (input.contains("resend"))
//                                                resendCode(user.getUser_mobile());
//                                            else
//                                                verifyAccount(user.getUser_id(), input);
//                                        }
//                                    }, new String[]{user.getUser_mobile()});
//                                }
//                                catch (Exception e)
//                                {
//                                    String err=e.getMessage();
//                                }
//                            }
//                            else
//                            {


//                            }
                            //errortext.setText("error4");
                            //WorkRequest bgworkrequest=new OneTimeWorkRequest.Builder(BackgroundWorker.class).build();
                            //WorkManager.getInstance(LoginActivity.this).enqueue(bgworkrequest);

                        }
                        else
                        {
                            hideProgressDialogWithTitle();
                            validUserListener.isUserValid(false);
                            Log.d("Login failed0: ",userinfo.getMessage());
                        }

//                        allcases.clear();
//                        Gson gson=new Gson();
//                        CaseInfo[] allcaseinfos= gson.fromJson(res,CaseInfo[].class);
//                        List<CaseInfo> listCases = new ArrayList<>(Arrays.asList(allcaseinfos));
//
//                        if(allcaseinfos.length==0) {
//                            //casesAdapter.setState(casesAdapter.STATE_NORMAL);
//                            allcases.addAll(listCases);
//
//                        }
//                        else {
//                            //casesAdapter.setState(casesAdapter.STATE_NORMAL);
//
//                            allcases.addAll(listCases);
//                        }
//                        casesAdapter.notifyDataSetChanged();


//
                    }
                    else
                    {

                        hideProgressDialogWithTitle();
                        validUserListener.isUserValid(false);
                        Log.d("Login failed1: ",response.code()+" "+response.errorBody().toString());
                    }
                    //Log.d("response_xx",message);

                } catch (Exception e) {
                    hideProgressDialogWithTitle();
                    validUserListener.isUserValid(false);
                    try {
                        String reserr = e.getMessage();

                        Log.d("Login failed2: ",reserr);

                        //errortext.setText("Login Failed2: " +reserr);

                    } catch (Exception ex) {

                    }
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                try{
                    validUserListener.isUserValid(false);
                }
                catch (Exception ees)
                {

                }

                hideProgressDialogWithTitle();

                Log.d("Login failed3: ",t.getLocalizedMessage());
            }
        });
    }

}
