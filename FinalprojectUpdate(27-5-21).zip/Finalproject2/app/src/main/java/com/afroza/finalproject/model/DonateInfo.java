package com.afroza.finalproject.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Keep
public class DonateInfo implements Serializable {
    @SerializedName("id")
    private int id;
    @SerializedName("user_id")
    private int user_id;
    @SerializedName("full_name")
    private String donor_name;
    @SerializedName("user_email")
    private String donor_email;
    @SerializedName("user_mobile")
    private String donor_mobile;
    @SerializedName("donate_title")
    private String donate_title;
    @SerializedName("donate_location")
    private String user_location;
    @SerializedName("donate_date")
    private String donate_date;
    @SerializedName("created_at")
    private String created_date;
    @SerializedName("donate_time")
    private String donate_time;
    @SerializedName("donate_name")
    private String donate_name;
    @SerializedName("category_id")
    private String category_id;
    @SerializedName("category_name")
    private String category_name;
    @SerializedName("type_id")
    private int type_id;
    @SerializedName("type_name")
    private String type_name;
    @SerializedName("qty")
    private double qty;
    @SerializedName("description")
    private String description;
    @SerializedName("hide_name")
    private int hide_name;
    @SerializedName("hide_mobile")
    private int hide_mobile;
    @SerializedName("hide_email")
    private int hide_email;
    @SerializedName("image_url")
    private String image_url;

    public DonateInfo() {
    }

    public DonateInfo(int id, int user_id, String donor_name, String donor_email, String donor_mobile, String donate_title, String user_location, String donate_date, String created_date, String donate_time, String donate_name, String category_id, String category_name, int type_id, String type_name, double qty, String description, int hide_name, int hide_mobile, int hide_email, String image_url) {
        this.id = id;
        this.user_id = user_id;
        this.donor_name = donor_name;
        this.donor_email = donor_email;
        this.donor_mobile = donor_mobile;
        this.donate_title = donate_title;
        this.user_location = user_location;
        this.donate_date = donate_date;
        this.created_date = created_date;
        this.donate_time = donate_time;
        this.donate_name = donate_name;
        this.category_id = category_id;
        this.category_name = category_name;
        this.type_id = type_id;
        this.type_name = type_name;
        this.qty = qty;
        this.description = description;
        this.hide_name = hide_name;
        this.hide_mobile = hide_mobile;
        this.hide_email = hide_email;
        this.image_url = image_url;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getDonor_name() {
        return donor_name;
    }

    public void setDonor_name(String donor_name) {
        this.donor_name = donor_name;
    }

    public String getUser_location() {
        return user_location;
    }

    public void setUser_location(String user_location) {
        this.user_location = user_location;
    }

    public String getDonate_date() {
        return donate_date;
    }

    public void setDonate_date(String donate_date) {
        this.donate_date = donate_date;
    }

    public String getDonate_time() {
        return donate_time;
    }

    public void setDonate_time(String donate_time) {
        this.donate_time = donate_time;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public int getType_id() {
        return type_id;
    }

    public void setType_id(int type_id) {
        this.type_id = type_id;
    }

    public String getType_name() {
        return type_name;
    }

    public void setType_name(String type_name) {
        this.type_name = type_name;
    }

    public double getQty() {
        return qty;
    }

    public void setQty(double qty) {
        this.qty = qty;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int isHide_name() {
        return hide_name;
    }

    public void setHide_name(int hide_name) {
        this.hide_name = hide_name;
    }

    public int isHide_mobile() {
        return hide_mobile;
    }

    public void setHide_mobile(int hide_mobile) {
        this.hide_mobile = hide_mobile;
    }

    public int isHide_email() {
        return hide_email;
    }

    public void setHide_email(int hide_email) {
        this.hide_email = hide_email;
    }

    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }

    public String getDonate_title() {
        return donate_title;
    }

    public void setDonate_title(String donate_title) {
        this.donate_title = donate_title;
    }

    public int getHide_name() {
        return hide_name;
    }

    public int getHide_mobile() {
        return hide_mobile;
    }

    public int getHide_email() {
        return hide_email;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getDonate_name() {
        return donate_name;
    }

    public void setDonate_name(String donate_name) {
        this.donate_name = donate_name;
    }

    public String getDonor_email() {
        return donor_email;
    }

    public void setDonor_email(String donor_email) {
        this.donor_email = donor_email;
    }

    public String getDonor_mobile() {
        return donor_mobile;
    }

    public void setDonor_mobile(String donor_mobile) {
        this.donor_mobile = donor_mobile;
    }

    @Override
    public String toString() {
        return "DonateInfo{" +
                "id=" + id +
                ", user_id=" + user_id +
                ", donor_name='" + donor_name + '\'' +
                ", donor_email='" + donor_email + '\'' +
                ", donor_mobile='" + donor_mobile + '\'' +
                ", donate_title='" + donate_title + '\'' +
                ", user_location='" + user_location + '\'' +
                ", donate_date='" + donate_date + '\'' +
                ", created_date='" + created_date + '\'' +
                ", donate_time='" + donate_time + '\'' +
                ", donate_name='" + donate_name + '\'' +
                ", category_id='" + category_id + '\'' +
                ", category_name='" + category_name + '\'' +
                ", type_id=" + type_id +
                ", type_name='" + type_name + '\'' +
                ", qty=" + qty +
                ", description='" + description + '\'' +
                ", hide_name=" + hide_name +
                ", hide_mobile=" + hide_mobile +
                ", hide_email=" + hide_email +
                ", image_url='" + image_url + '\'' +
                '}';
    }
}
