package com.afroza.finalproject.ui;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;

import com.afroza.finalproject.R;
import com.afroza.finalproject.model.DonateInfo;
import com.afroza.finalproject.model.RegistrationResponse;
import com.afroza.finalproject.model.User;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.networktask.UserApis;
import com.afroza.finalproject.utils.LoginHelper;
import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;

public class DonationDetailActivity extends BaseActivity {

    TextView tvTitle,tvLocation,tvPostOn,tvCategory,tvType,tvItem,tvQty,tvDate,tvTime,tvDesc, tvName,tvEmail,tvMobile;
    String to,subject,message;
    Button btnSave;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donation_details);
        toolbar=findViewById(R.id.toolBar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("");
        tvTitle=findViewById(R.id.tvTitle);
        tvLocation=findViewById(R.id.tvLocation);
        tvPostOn=findViewById(R.id.tvPostOn);
        tvCategory=findViewById(R.id.tvCategory);
        tvType=findViewById(R.id.tvType);
        tvItem=findViewById(R.id.tvItem);
        tvQty=findViewById(R.id.tvQty);
        tvDate=findViewById(R.id.tvDate);
        tvTime=findViewById(R.id.tvTime);
        tvDesc=findViewById(R.id.tvDesc);
        tvName=findViewById(R.id.tvName);
        tvEmail=findViewById(R.id.tvEmail);
        tvMobile=findViewById(R.id.tvMobile);
        btnSave=findViewById(R.id.accSave);

        setValues();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent email = new Intent(Intent.ACTION_SEND);
                subject="this is test subject";
                message="some text";
                email.putExtra(Intent.EXTRA_EMAIL, new String[]{ to});
                email.putExtra(Intent.EXTRA_SUBJECT, subject);
                email.putExtra(Intent.EXTRA_TEXT, message);

//need this to prompts email client only
                email.setType("message/rfc822");

                startActivity(Intent.createChooser(email, "Choose an Email client :"));
            }
        });

    }

    private void setValues() {

            try {
                Bundle bundle=getIntent().getExtras();
                DonateInfo donateInfo=(DonateInfo)bundle.getSerializable("donateinfo");
                tvTitle.setText(donateInfo.getDonate_title());
                tvLocation.setText(donateInfo.getUser_location());
                tvPostOn.setText(donateInfo.getCreated_date());
                tvCategory.setText(donateInfo.getCategory_name());
                tvType.setText(donateInfo.getType_name());
                tvItem.setText(donateInfo.getDonate_name());
                tvQty.setText(String.valueOf(donateInfo.getQty()));
                tvDate.setText(donateInfo.getDonate_date());
                tvTime.setText(donateInfo.getDonate_time());
                tvDesc.setText(donateInfo.getDescription());
                if(donateInfo.isHide_name()==1)
                {
                    tvName.setText("Anonymous");
                }
                else
                {
                    tvName.setText(donateInfo.getDonor_name());
                }
                tvEmail.setText(donateInfo.getDonor_email());
                to=donateInfo.getDonor_email();
                if(donateInfo.isHide_mobile()==1)
                {
                    tvMobile.setText("NA");
                }
                else {
                    tvMobile.setText(donateInfo.getDonor_mobile());
                }
                if(bundle.getInt("flag")==0)
                    btnSave.setVisibility(View.GONE);
            }
            catch (Exception e)
            {

            }

    }

}