package com.afroza.finalproject.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.afroza.finalproject.R;
import com.afroza.finalproject.model.User;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.networktask.StaticClass;
import com.afroza.finalproject.networktask.UserApis;
import com.afroza.finalproject.utils.LoginHelper;
import com.bumptech.glide.Glide;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;

public class ProfileActivity extends BaseActivity implements PopupMenu.OnMenuItemClickListener {
Toolbar toolbar;
LinearLayout accLay,passLay;
    private static final int CAMERA_REQUEST_CODE_CUSTOM = 778;

    public  final int CAMERA_REQUEST_CODE = 102;
    public  final int GALLERY_REQUEST_CODE = 105;
    ProgressDialog progressDialog;
    private AlertDialog alertDialog;
    private AlertDialog.Builder builder;
    ImageView editphoto,selectedImage;
    TextView logoutTV,username,useremail,usermobile;
    User user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_layout);
        toolbar=findViewById(R.id.toolBar);
        accLay=findViewById(R.id.accLay);
        passLay=findViewById(R.id.passLay);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("");
        logoutTV=findViewById(R.id.logoutTV);
        username=findViewById(R.id.username);
        useremail=findViewById(R.id.usermail);
        usermobile=findViewById(R.id.usermobile);
        logoutTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logoutAction();
            }
        });
        user=LoginHelper.getCurrentUser();
        progressDialog = new ProgressDialog(this);
        builder=new AlertDialog.Builder(this);
        selectedImage=findViewById(R.id.circleview);
        editphoto=findViewById(R.id.editPhoto);
        editphoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu=new PopupMenu(ProfileActivity.this,view);
                MenuInflater inflater=popupMenu.getMenuInflater();
                popupMenu.setOnMenuItemClickListener(ProfileActivity.this);
                inflater.inflate(R.menu.context_menu,popupMenu.getMenu());
                popupMenu.show();
            }
        });
initValues();
loadDefaultImage();
accLay.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent=new Intent(ProfileActivity.this,AccActivity.class);
        startActivity(intent);
    }
});
passLay.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent=new Intent(ProfileActivity.this,PasswordChangeActivity.class);
        startActivity(intent);
    }
});
    }
    private void initValues()
    {
        try {
            username.setText(LoginHelper.getCurrentUser().getUser_name());
            useremail.setText(LoginHelper.getCurrentUser().getUser_email());
            usermobile.setText(LoginHelper.getCurrentUser().getUser_mobile());
        }
        catch (Exception e)
        {

        }
    }
    private void logoutAction()
    {
       LoginHelper.clearLoginSession(this);
        SingleTonClass.getInstance().setCurrentuser(null);
        Intent intent=new Intent(ProfileActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //overridePendingTransition(R.anim.trans_left_in,R.anim.trans_left_out);
        overridePendingTransition(R.anim.trans_right_in,R.anim.trans_right_out);
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;

    }
    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_gallery:
                try {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    //startActivityForResult(gallery, GALLERY_REQUEST_CODE);
                    //Intent intent=new Intent();
                    intent.setType("image/*");
                    //intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(intent, GALLERY_REQUEST_CODE);
                }
                catch (Exception ex)
                {

                }
                return true;
            case R.id.nav_camera:
                try {
                    Intent intent=new Intent(ProfileActivity.this, CameraActivity.class);
                    startActivityForResult(intent,CAMERA_REQUEST_CODE_CUSTOM);
                }
                catch (Exception ex)
                {
                    String err=ex.getMessage();
                }
                return true;
            default:
                return false;
        }

    }
    private void loadDefaultImage()
    {
        user=LoginHelper.getCurrentUser();
        //user=LoginHelper.getCurrentUser()!=null?LoginHelper.getCurrentUser():user;
        String url= StaticClass.PROFILE_IMAGE_URL+user.getUser_image();
        Glide.with(ProfileActivity.this).load(url).error(getResources().getDrawable(R.drawable.ic_profile_svg)).into(selectedImage);

    }
    private void uploadImage(String base64image) {

        int user_id= LoginHelper.getCurrentUser()!=null?LoginHelper.getCurrentUser().getUser_id():0;

        if(user_id==0)return;
        showProgressDialogWithTitle("","uploading image.....");
        Retrofit retrofit = NetworkClient.getRetrofit();

        //RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);
//        double thresv =Double.parseDouble(PreferenceManager.getDefaultSharedPreferences(CameraActivity.this).getString("threshold", "0.25"));
//        if(thresv==0 )
//            thresv=0.25;
        //RequestBody thresbody = RequestBody.create(MediaType.parse("text/plain"), thresv);

//        String filename=file.getName();
//        String fileabspath=file.getAbsolutePath();
//        MultipartBody.Part parts = MultipartBody.Part.createFormData("image", file.getName(), requestBody);

        //RequestBody userid = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(user_id));

        UserApis userApis = retrofit.create(UserApis.class);
        //base64image= "data:image/jpg;base64,"+base64image;
        Call<String> call = userApis.uploadImage(base64image,user_id);
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, retrofit2.Response<String> response) {
                String res=response.body();
                try {
                    hideProgressDialogWithTitle();

                    if(!res.contains("failed"))
                    {
                        //Uri mUri=cUri;


                        User user=LoginHelper.getCurrentUser();
                        user.setUser_image(res);
                        LoginHelper.setCurrentUser(user);
                        loadDefaultImage();

                    }
                    else
                    {

                        hideProgressDialogWithTitle();
//                                                           //Toast.makeText(MainActivity.this,"Match Found",Toast.LENGTH_LONG).show();
                    }
                    //Log.d("response_xx",msg);

                } catch (Exception e) {
                    hideProgressDialogWithTitle();

                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                checkInternetWithException(t);
                hideProgressDialogWithTitle();
                builder.setMessage("Uploading Failed")
                        .setCancelable(false)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                alertDialog.dismiss();

                            }
                        });
                alertDialog = builder.create();
                alertDialog.setTitle("Failed");
                alertDialog.show();
            }
        });
    }
    private void showProgressDialogWithTitle(String title, String substring) {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);
        //Setting Title
        progressDialog.setTitle(title);
        progressDialog.setMessage(substring);
        progressDialog.show();

    }

    // Method to hide/ dismiss Progress bar
    private void hideProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.dismiss();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        Log.d("cameraaaaaaa:","entering");
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            selectedImage.setImageBitmap(imageBitmap);
        }
        else if (requestCode == CAMERA_REQUEST_CODE_CUSTOM && resultCode == RESULT_OK) {
            //Bundle extras = data.getExtras();
            //Bitmap imageBitmap = (Bitmap) extras.get("data");
            //selectedImage.setImageBitmap(imageBitmap);
            loadDefaultImage();
        }
//        if (requestCode == CAMERA_REQUEST_CODE) {
//            if (resultCode == Activity.RESULT_OK) {
//
//                File file = new File(currentPhotoPath);
//                Uri uri = Uri.fromFile(file);
//               // selectedImage.setImageURI(uri);
//
//
//                Bitmap bitmap;
//                try {
//                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
//                   Bitmap thumbnail = ThumbnailUtils.extractThumbnail(bitmap,96,96); // if you mind scaling
//                    FileOutputStream fileOutputStream=new FileOutputStream(file);
//                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                    thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bitmap is required image which have to send  in Bitmap form
//                    byte[] byteArray = baos.toByteArray();
//
//                    String encodedImage = Base64.encodeToString(byteArray, Base64.DEFAULT);
//                    uploadImage(encodedImage);
//                } catch (FileNotFoundException e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                } catch (IOException e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
//
//
//                //photo = Bitmap.createScaledBitmap(photo, 100, 100, false);
////                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
////                photo.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
//
//               // File f = new File(currentPhotoPath);
////                f.createNewFile();
////                FileOutputStream fo = new FileOutputStream(f);
////                fo.write(bytes.toByteArray());
////                fo.close();
//
//
//
//                //File f = new File(currentPhotoPath);
//               // Bitmap imageBitmap=BitmapFactory.decodeFile(f.getAbsolutePath());
//               //imageBitmap = (Bitmap) extras.get("data");
//
//
//                //selectedImage.setImageBitmap(thumb);
//
//
//
//            }
////                File f = new File(currentPhotoPath);
////                selectedImage.setImageURI(Uri.fromFile(f));
////                selectedImage.buildDrawingCache();
////                mainbitmap = selectedImage.getDrawingCache();
////                Log.d("tag", "ABsolute Url of Image is " + Uri.fromFile(f));
////
////                Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
////                Uri contentUri = Uri.fromFile(f);
////                cUri=contentUri;
////                mediaScanIntent.setData(contentUri);
////                this.sendBroadcast(mediaScanIntent);
//
//
//        }

        else if (requestCode == GALLERY_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {


                Uri uri = data.getData();
                //selectedImage.setImageURI(uri);

                //cUri = contentUri;

                try {
                    InputStream inputStream = getBaseContext().getContentResolver().openInputStream(uri);
                    Bitmap bm = BitmapFactory.decodeStream(inputStream);

                    // ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    // byte[] byteArray = stream.toByteArray();
                    Bitmap thumbnail = ThumbnailUtils.extractThumbnail(bm,120,120); // if you mind scaling
                    //FileOutputStream fileOutputStream=new FileOutputStream(file);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bitmap is required image which have to send  in Bitmap form
                    byte[] byteArray = baos.toByteArray();

                    String encodedImage = Base64.encodeToString(byteArray, Base64.DEFAULT);
                    uploadImage(encodedImage);
                    return;
                    //bind.photo.setImageBitmap(bm);
                    //Log.i("SANJAY ", "onActivityResult: " + saveBitMap(this, bm));
                    //uri = Uri.fromFile(saveBitMap(this, bm));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }



//                currentPhotoPath = uri.toString();
//                File file = new File(currentPhotoPath);
//                Bitmap bitmap;
//                try {
//                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
//                    Bitmap thumbnail = ThumbnailUtils.extractThumbnail(bitmap,96,96); // if you mind scaling
//                    selectedImage.setImageBitmap(thumbnail);
//                    FileOutputStream fileOutputStream=new FileOutputStream(file);
//                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                    thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bitmap is required image which have to send  in Bitmap form
//                    byte[] byteArray = baos.toByteArray();
//
//                    String encodedImage = Base64.encodeToString(byteArray, Base64.DEFAULT);
//                    uploadImage(encodedImage);
//                } catch (FileNotFoundException e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                } catch (IOException e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
                try {
//                    Uri contentUri = data.getData();
//                    //cUri = contentUri;
//                    currentPhotoPath = contentUri.toString();
//
//                    selectedImage.setImageURI(contentUri);
//                    uploadImage();
                    //selectedImage.buildDrawingCache();
                    //mainbitmap = selectedImage.getDrawingCache();
                }
                catch (Exception ex) {
                    builder.setMessage("File or file path Error")
                            .setCancelable(false)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    alertDialog.dismiss();

                                }
                            });
                    alertDialog = builder.create();
                    alertDialog.setTitle("Failed");
                    alertDialog.show();
                    //Toast.makeText(MainActivity.this,"File read error",Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}