package com.afroza.finalproject.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Keep
public class Attachment implements Serializable {
    @SerializedName("id")
    private int file_id;
    @SerializedName("file_name")
    private String file_name;
    @SerializedName("file_url")
    private String file_url;


    public Attachment() {
    }

    public Attachment(int file_id, String file_name, String file_url) {
        this.file_id = file_id;
        this.file_name = file_name;
        this.file_url = file_url;
    }

    public int getFile_id() {
        return file_id;
    }

    public void setFile_id(int file_id) {
        this.file_id = file_id;
    }

    public String getFile_name() {
        return file_name;
    }

    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }

    public String getFile_url() {
        return file_url;
    }

    public void setFile_url(String file_url) {
        this.file_url = file_url;
    }

    @Override
    public String toString() {
        return "Attachment{" +
                "file_id=" + file_id +
                ", file_name='" + file_name + '\'' +
                ", file_url='" + file_url + '\'' +
                '}';
    }
}
