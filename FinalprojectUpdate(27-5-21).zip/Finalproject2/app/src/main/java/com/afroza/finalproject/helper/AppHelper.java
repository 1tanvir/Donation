package com.afroza.finalproject.helper;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.snackbar.Snackbar;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.schedulers.Schedulers;

import static com.afroza.finalproject.networktask.StaticClass.SHAREPREF;


public class AppHelper {
    public static long milliseconds(String date)
    {
        //String date_ = date;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        try
        {
            Date mDate = sdf.parse(date);
            long timeInMilliseconds = mDate.getTime();

            return timeInMilliseconds;
        }
        catch (ParseException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return 0;
    }
    public static void saveSharedPref(String prefName,String prefVal)
    {
        SharedPreferences sharedPreferences=DaanApplication.getAppContext().getSharedPreferences(SHAREPREF, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(prefName, prefVal);
        editor.apply();
    }
    public static String getSharedPrefValue(String prefName)
    {
        SharedPreferences sharedPreferences=DaanApplication.getAppContext().getSharedPreferences(SHAREPREF, Context.MODE_PRIVATE);
       String prefVal=sharedPreferences.getString(prefName,"");
       return prefVal;
    }
    public static int getCurrentUserId()
    {
        int user_id=0;
        SharedPreferences sharedPreferences=DaanApplication.getAppContext().getSharedPreferences(SHAREPREF, Context.MODE_PRIVATE);
        user_id=sharedPreferences.getInt("user_id",0);
        return user_id;
    }
    public static Single<Boolean> hasInternetConnection() {
        return Single.fromCallable(() -> {
            try {
                // Connect to Google DNS to check for connection
                int timeoutMs = 1500;
                Socket socket = new Socket();
                InetSocketAddress socketAddress = new InetSocketAddress("8.8.8.8", 53);

                socket.connect(socketAddress, timeoutMs);
                socket.close();

                return true;
            } catch (IOException e) {
                return false;
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
    }


    public static boolean internetIsConnected() {
        try {
            String command = "ping -c 1 google.com";
            return (Runtime.getRuntime().exec(command).waitFor() == 0);
        } catch (Exception e) {
            return false;
        }
    }
//    private boolean isNetworkConnected(Context context) {
//        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
//        return cm.getActiveNetworkInfo() != null;
//    }
//    Disposable networkDisposable, internetDisposable;
//    private void networkReachAbilityCheck() {
//
//        networkDisposable = ReactiveNetwork.observeNetworkConnectivity(getApplicationContext())
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(
//
//                        connectivity -> {
//                            Log.d(TAG, connectivity.toString());
//                            final NetworkInfo.State state = connectivity.state();
//                            final String name = connectivity.typeName();
//
//                            if (state == NetworkInfo.State.CONNECTED) {
//
//                                InternetObservingSettings settings = InternetObservingSettings
//                                        .host(AppConfig.REACHABILITY_TEST_URL)
//                                        .strategy(new SocketInternetObservingStrategy())
//                                        .build();
//
//
//                                internetDisposable = ReactiveNetwork.observeInternetConnectivity(settings)
//                                        .subscribeOn(Schedulers.io())
//                                        .observeOn(AndroidSchedulers.mainThread())
//                                        .subscribe(
//                                                isConnected -> {
//                                                    isInternetAvailable = isConnected;
//
//                                                    if (isConnected) {
//                                                        //showSnackBar( getString(R.string.msg_not_available), R.color.green, Snackbar.LENGTH_LONG);
//                                                        hideSnakeBar();
//                                                        //internet connection back call cached api request
//                                                        cacheQueCall();
//
//                                                    } else {
//                                                        showSnackBar(getString(R.string.msg_not_available), R.color.red, Snackbar.LENGTH_INDEFINITE);
//                                                    }
//                                                }
//
//                                        );
//
//                            } else {
//                                isInternetAvailable = false;
//                                showSnackBar(getString(R.string.msg_not_available), R.color.red, Snackbar.LENGTH_INDEFINITE);
//                            }
//
//
//                        },
//
//                        throwable -> {
//                            showSnackBar(getString(R.string.msg_not_available), R.color.red, Snackbar.LENGTH_INDEFINITE);
//                        });
//
//    }


    private static View getRootView(Activity activity) {
        final ViewGroup contentViewGroup = (ViewGroup) activity.findViewById(android.R.id.content);
        View rootView = null;

        if (contentViewGroup != null)
            rootView = contentViewGroup.getChildAt(0);

        if (rootView == null)
            rootView = activity.getWindow().getDecorView().getRootView();

        return rootView;
    }
    static Snackbar snackbar;
    public static void showSnackBar(Activity activity,String res, int color, int duration) {
        final View rootView = getRootView(activity);
        if (rootView != null) {
            snackbar = Snackbar.make(rootView, res, duration);
            snackbar.getView().setBackgroundColor(activity.getResources().getColor(color));
            Snackbar.SnackbarLayout layout = (Snackbar.SnackbarLayout) snackbar.getView();
            snackbar.show();
        }
    }

    public static void hideSnakeBar() {
        if (snackbar != null) snackbar.dismiss();
    }

//    public static void updateProfileInBackground(final User currentuser)
//    {
//
//
//        //showProgressDialogWithTitle("","Updating....");
//        Retrofit retrofit = NetworkClient.getRetrofit();
//
//        UserApis userApis = retrofit.create(UserApis.class);
//
//        Call<String> call = userApis.updateProfile(
//                currentuser.getUser_id(),
//                currentuser.getUser_name(),
//                currentuser.getUser_lawyer_id(),
//                currentuser.getUser_email(),
//                currentuser.getUser_mobile(),
//                currentuser.getUser_address()
//        );
//        // Call<JsonArray> call = casesApis.getCases();
//        call.enqueue(new Callback<String>() {
//            @Override
//            public void onResponse(Call<String> call, retrofit2.Response<String> response) {
//                String res=response.body();
//                try {
//                    //hideProgressDialogWithTitle();
//
//                    //if(res.size()==0)
//
//                    if(response.code()==200)
//                    {
//                        if(res.contains("success"))
//                        {
//                            SingleTonClass.getInstance().setCurrentuser(currentuser);
//                        }
//                    }
//                    else
//                    {
//                    }
//                    //Log.d("response_xx",message);
//
//                } catch (Exception e) {
//                   // hideProgressDialogWithTitle();
//                    try {
//                        String reserr = e.getMessage();
//
//
//                    } catch (Exception ex) {
//
//                    }
//                    e.printStackTrace();
//                }
//
//            }
//
//            @Override
//            public void onFailure(Call<String> call, Throwable t) {
//                //hideProgressDialogWithTitle();
//
//            }
//        });
//    }
}
