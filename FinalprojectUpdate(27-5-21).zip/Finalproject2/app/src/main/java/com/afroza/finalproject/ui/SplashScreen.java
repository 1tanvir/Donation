package com.afroza.finalproject.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.appcompat.app.ActionBar;

import com.afroza.finalproject.R;
import com.afroza.finalproject.helper.AppHelper;
import com.afroza.finalproject.interfaces.ValidUserListener;
import com.afroza.finalproject.model.Category;
import com.afroza.finalproject.networktask.GeneralApis;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.utils.LoginHelper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class SplashScreen extends BaseActivity {
    /**
     * Whether or not the system UI should be auto-hidden after
     * {@link #AUTO_HIDE_DELAY_MILLIS} milliseconds.
     */
    private static final boolean AUTO_HIDE = true;

    /**
     * If {@link #AUTO_HIDE} is set, the number of milliseconds to wait after
     * user interaction before hiding the system UI.
     */
    private static final int AUTO_HIDE_DELAY_MILLIS = 2000;
    /** Duration of wait **/
    private static final int SPLASH_DISPLAY_LENGTH = 1600;
    /**
     * Some older devices needs a small delay between UI widget updates
     * and a change of the status and navigation bar.
     */
    private static final int UI_ANIMATION_DELAY = 300;
    private final Handler mHideHandler = new Handler();
    private View mContentView;
    private ProgressBar progressBar;
    private final Runnable mHidePart2Runnable = new Runnable() {
        @SuppressLint("InlinedApi")
        @Override
        public void run() {
            // Delayed removal of status and navigation bar

            // Note that some of these constants are new as of API 16 (Jelly Bean)
            // and API 19 (KitKat). It is safe to use them, as they are inlined
            // at compile-time and do nothing on earlier devices.
            mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }
    };
    private View mControlsView;
    private final Runnable mShowPart2Runnable = new Runnable() {
        @Override
        public void run() {
            // Delayed display of UI elements
            ActionBar actionBar = getSupportActionBar();
            if (actionBar != null) {
                actionBar.show();
            }
            mControlsView.setVisibility(View.VISIBLE);
        }
    };
    private boolean mVisible;
    private final Runnable mHideRunnable = new Runnable() {
        @Override
        public void run() {
            hide();
        }
    };
    /**
     * Touch listener to use for in-layout UI controls to delay hiding the
     * system UI. This is to prevent the jarring behavior of controls going away
     * while interacting with activity UI.
     */
    private final View.OnTouchListener mDelayHideTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            switch (motionEvent.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (AUTO_HIDE) {
                        delayedHide(AUTO_HIDE_DELAY_MILLIS);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    view.performClick();
                    break;
                default:
                    break;
            }
            return false;
        }
    };
ImageView imgLoader;
WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (!isTaskRoot()) {
            finish();
            return;
        }
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash_screen);
        //webView=findViewById(R.id.wv);
        //webView.loadUrl("file:///android_res/drawable/mainload.svg"); // point it to the SVG
       // webView.setBackgroundColor(0x00000000);
        imgLoader=findViewById(R.id.imgLoader);
        progressBar=findViewById(R.id.loading);
        loadList();
// Get the Drawable custom_progressbar
       // Drawable draw=getResources().getDrawable(R.drawable.mainspin);
// set the drawable as progress drawable
       // GlideDrawableImageViewTarget imageViewTarget = new GlideDrawableImageViewTarget(imageView);

        //Glide.with(this).asDrawable().load(R.drawable.ic_double_ring_1s_200px).into(imgLoader);
//        mVisible = true;
//        mControlsView = findViewById(R.id.fullscreen_content_controls);
//        mContentView = findViewById(R.id.fullscreen_content);




            /* New Handler to start the Menu-Activity
             * and close this Splash-Screen after some seconds.*/
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {

                LoginHelper.checkUserLoginSession(SplashScreen.this, new ValidUserListener() {
                            @Override
                            public void isUserValid(boolean isValid) {
                            if(isValid)
                            {
                                Intent intent=new Intent(SplashScreen.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                            else
                            {
                                Intent intent=new Intent(SplashScreen.this,LoginActivity.class);
                                startActivity(intent);
                                finish();
                            }
                            }
                        }
                );


//                Intent intent=new Intent(SplashScreen.this,LoginActivity.class);
//                startActivity(intent);
//                finish();

                          }
        }, SPLASH_DISPLAY_LENGTH);
//            new Handler().postDelayed(new Runnable(){
//                @Override
//                public void run() {
//                    /* Create an Intent that will start the Menu-Activity. */
//
//                }
//            }, SPLASH_DISPLAY_LENGTH);

        // Set up the user interaction to manually show or hide the system UI.
//        //mContentView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                toggle();
//            }
//        });

        // Upon interacting with UI controls, delay any scheduled hide()
        // operations to prevent the jarring behavior of controls going away
        // while interacting with the UI.
       // findViewById(R.id.dummy_button).setOnTouchListener(mDelayHideTouchListener);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        // Trigger the initial hide() shortly after the activity has been
        // created, to briefly hint to the user that UI controls
        // are available.
        //delayedHide(100);
    }

    private void toggle() {
        if (mVisible) {
            hide();
        } else {
            show();
        }
    }

    private void hide() {
        // Hide UI first
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        mControlsView.setVisibility(View.GONE);
        mVisible = false;

        // Schedule a runnable to remove the status and navigation bar after a delay
        mHideHandler.removeCallbacks(mShowPart2Runnable);
        mHideHandler.postDelayed(mHidePart2Runnable, UI_ANIMATION_DELAY);
    }
    private void loadList()
    {
       // user_id= LoginHelper.getCurrentUser().getUser_id();


        Retrofit retrofit = NetworkClient.getRetrofit();

        GeneralApis generalApis = retrofit.create(GeneralApis.class);

        Call<JsonObject> call = generalApis.loadCategories();
        // Call<JsonArray> call = casesApis.getCases();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject res=response.body();
                try {


                    if(response.code()==200)
                    {
                        JsonArray categories=res.getAsJsonArray("categories");

                        Gson gson=new Gson();
                        Category[] categoryList=gson.fromJson(categories,Category[].class);

                        String categoriesSerial=gson.toJson(categoryList);
                        AppHelper.saveSharedPref("categories",categoriesSerial);




                    }
                    else
                    {
//
                    }
                    //Log.d("response_xx",message);

                } catch (Exception e) {
                    //hideProgressDialogWithTitle();
                    try {
                        String reserr = e.getMessage();



                    } catch (Exception ex) {

                    }
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                String err=t.getLocalizedMessage();


            }
        });
    }
    private void show() {
        // Show the system bar
        mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        mVisible = true;

        // Schedule a runnable to display UI elements after a delay
        mHideHandler.removeCallbacks(mHidePart2Runnable);
        mHideHandler.postDelayed(mShowPart2Runnable, UI_ANIMATION_DELAY);
    }

    /**
     * Schedules a call to hide() in delay milliseconds, canceling any
     * previously scheduled calls.
     */
    private void delayedHide(int delayMillis) {
        mHideHandler.removeCallbacks(mHideRunnable);
        mHideHandler.postDelayed(mHideRunnable, delayMillis);
    }
}