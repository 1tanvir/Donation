package com.afroza.finalproject.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Keep
public class User implements Serializable {
    @SerializedName("id")
    private int user_id;
    @SerializedName("full_name")
    private String user_name;
    @SerializedName("user_email")
    private String user_email;
    @SerializedName("user_mobile")
    private String user_mobile;
    @SerializedName("username")
    private String username;
    @SerializedName("image_url")
    private String user_image;



    public User() {
    }

    public User(int user_id, String user_name, String user_email, String user_mobile, String username, String user_image) {
        this.user_id = user_id;
        this.user_name = user_name;
        this.user_email = user_email;
        this.user_mobile = user_mobile;
        this.username = username;
        this.user_image = user_image;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getUser_mobile() {
        return user_mobile;
    }

    public void setUser_mobile(String user_mobile) {
        this.user_mobile = user_mobile;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "User{" +
                "user_id=" + user_id +
                ", user_name='" + user_name + '\'' +
                ", user_email='" + user_email + '\'' +
                ", user_mobile='" + user_mobile + '\'' +
                ", username='" + username + '\'' +
                ", user_image='" + user_image + '\'' +
                '}';
    }
}
