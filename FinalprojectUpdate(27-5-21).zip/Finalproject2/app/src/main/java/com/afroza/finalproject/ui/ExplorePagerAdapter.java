package com.afroza.finalproject.ui;

import android.content.Context;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;


import com.afroza.finalproject.helper.AppHelper;
import com.afroza.finalproject.model.Category;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
public class ExplorePagerAdapter extends FragmentPagerAdapter {


    private static List<Category> categories=new ArrayList<>();
    private final Context mContext;

    public ExplorePagerAdapter(Context context, FragmentManager fm) {
        super(fm,BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        mContext = context;
        categories=new ArrayList<>();
       setCategories();
        //categories=Arrays.asList(categoryList);


    }
    private void setCategories()
    {
        String categoriesSerial= AppHelper.getSharedPrefValue("categories");
        Gson gson=new Gson();
        Category[] categoryarr=gson.fromJson(categoriesSerial,Category[].class);
        List<Category> categoryList= Arrays.asList(categoryarr);
        Category category= new Category(0,"All","");
        categories.add(category);
        categories.addAll(categoryList);
    }

    @Override
    public Fragment getItem(int position) {
        // getItem is called to instantiate the fragment for the given page.
        // Return a PlaceholderFragment (defined as a static inner class below).

                return DonorFragment.newInstance(position);

       // return PlaceholderFragment.newInstance(position + 1);
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return categories.get(position).getCategory_name();
    }

    @Override
    public int getCount() {
        // Show 2 total pages.
        return categories.size();
    }
}