package com.afroza.finalproject.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Keep
public class CategoryType implements Serializable {
    @SerializedName("id")
    private int type_id;
    @SerializedName("category_id")
    private int category_id;
    @SerializedName("type_name")
    private String type_name;

    public CategoryType() {
    }

    public CategoryType(int type_id, int category_id, String type_name) {
        this.type_id = type_id;
        this.category_id = category_id;
        this.type_name = type_name;
    }

    public int getType_id() {
        return type_id;
    }

    public void setType_id(int type_id) {
        this.type_id = type_id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public String getType_name() {
        return type_name;
    }

    public void setType_name(String type_name) {
        this.type_name = type_name;
    }

    @Override
    public String toString() {
        return type_name;
    }
}
