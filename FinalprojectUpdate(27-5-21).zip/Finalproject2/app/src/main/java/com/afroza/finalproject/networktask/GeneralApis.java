package com.afroza.finalproject.networktask;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface GeneralApis {

    @GET("api/categories")
    Call<JsonObject> loadCategories();

    @GET("api/feedbacks")
    Call<JsonArray> getFeedbacks();

    @GET("api/dlist/category/{category_id}")
    Call<JsonArray> loadDonatelist(@Path("category_id")int category_id);

    @GET("api/dlist/user/{user_id}")
    Call<JsonArray> loadUserDonatelist(@Path("user_id")int user_id);

    @FormUrlEncoded
    @POST("api/saveD")
    Call<JsonObject> saveDonate(

            @Field("user_id") int user_id,
            @Field("category_id") int category_id,
            @Field("type_id") int type_id,
            @Field("donate_title") String donate_title,
            @Field("donate_location") String donate_location,
            @Field("donate_date") String donate_date,
            @Field("donate_time") String donate_time,
            @Field("donate_name") String donate_name,
            @Field("description") String description,
            @Field("qty") String qty,

            @Field("hide_mobile") int hide_mobile,
            @Field("hide_name") int hide_name
    );


    @GET("api/category/{category_id}")
    Call<JsonObject> loadTypes(@Path("category_id") int category_id);
    @GET("api/about")
    Call<String> loadAbout();

    @GET("api/help")
    Call<String> loadHelp();

    @GET("api/support-tickets/user/{user_id}")
    Call<JsonArray> loadIssues(@Path("user_id") int user_id);

    @GET("api/support-ticket-replies/{ticket_id}")
    Call<JsonArray> loadReplies(@Path("ticket_id") int ticket_id);

    @Multipart
    @POST("api/support-ticket-reply/file")
    Call<JsonObject> saveReplyFile(
            @Part MultipartBody.Part file,
            @Part("filename") String filename,
            @Part("ticket_id") int ticket_id,
            @Part("user_id") int user_id
    );

    @FormUrlEncoded
    @POST("api/support-ticket-reply")
    Call<JsonObject> saveReply(
            @Field("ticket_id") int ticket_id,
            @Field("user_id") int user_id,
            @Field("reply") String reply
    );
    @FormUrlEncoded
    @POST("api/support-tickets/closeIssue")
    Call<JsonObject> closeIssue(
            @Field("ticket_id") int ticket_id,
            @Field("user_id") int user_id
    );

    @FormUrlEncoded
    @POST("api/support-tickets")
    Call<JsonObject> submitIssue(

                                 @Field("user_id") int user_id,
                                 @Field("subject") String subject,
                                 @Field("description") String description
    );
    @Multipart
    @POST("api/support-tickets")
    Call<JsonObject> submitIssueFile(

            @Part MultipartBody.Part file,
            @Part("filename") String filename,
            @Part("user_id") int user_id,
            @Part("subject") String subject,
            @Part("description") String description
    );

    @GET("api/privacy")
    Call<String> loadPrivacy();

    @FormUrlEncoded
    @POST("api/sendFeedback")
    Call<String> sendFeedback(
            @Field("created_by") String user_name,
            @Field("title") String titletext,
            @Field("feedback") String bodytext
    );


    @FormUrlEncoded
    @POST("api/addPromoCode")
    Call<String> addPromoCode(
            @Field("user_id") int user_id,
            @Field("promotext") String promotext
    );
}
