package com.afroza.finalproject.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.afroza.finalproject.R;
import com.afroza.finalproject.model.Category;
import com.afroza.finalproject.networktask.StaticClass;
import com.bumptech.glide.Glide;


import java.util.ArrayList;
import java.util.List;

public class RVAdapter extends RecyclerView.Adapter<RVAdapter.CustomViewHolder> {
    List<Category> categories = new ArrayList<>();
    ;
    Context context;
    OnRVClickListener onRVClickListener;
    protected ItemListener mListener;

    public RVAdapter(Context context, List<Category> categories,OnRVClickListener onRVClickListener) {
        this.context = context;
        this.categories = categories;
        this.onRVClickListener=onRVClickListener;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.category_card, parent, false);

        return new CustomViewHolder(view, onRVClickListener);

    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        Category category = categories.get(position);
        holder.cat_name.setText(category.getCategory_name());
        String imageurl = StaticClass.CATEGORY_IMAGE_URL + category.getImage_url();
        Glide.with(context).load(imageurl).error(R.drawable.basket).fallback(R.drawable.basket).into(holder.img);
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    public interface ItemListener {
        void onItemClick(Category item);
    }


    class CustomViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView cat_name;
        ImageView img;
        OnRVClickListener onRVClickListener;

        public CustomViewHolder(@NonNull View itemView, OnRVClickListener onRVClickListener) {
            super(itemView);
            cat_name = itemView.findViewById(R.id.catName);
            img = itemView.findViewById(R.id.catImage);
            this.onRVClickListener = onRVClickListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onRVClickListener.onRVItemClick(getAdapterPosition());
        }


    }
    public interface OnRVClickListener {
        void onRVItemClick(int position);
    }
}