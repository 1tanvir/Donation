package com.afroza.finalproject.interfaces;

public interface HttpResponseListener {
    void onResponse(Object response);
    void onError(String message);
}
