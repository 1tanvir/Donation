package com.afroza.finalproject.interfaces;

public interface ClickListenerM {
    void onClick(String[] input);
}
