package com.afroza.finalproject.ui;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.afroza.finalproject.R;
import com.afroza.finalproject.adapters.DonationAdapter;
import com.afroza.finalproject.interfaces.HttpResponseListener;
import com.afroza.finalproject.model.DonateInfo;

import com.afroza.finalproject.networktask.GeneralApis;
import com.afroza.finalproject.networktask.NetworkClient;

import com.afroza.finalproject.utils.RecyclerViewEmptySupport;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

//import com.rockerhieu.rvadapter.states.StatesRecyclerViewAdapter;

/**
 * A placeholder fragment containing a simple view.
 */
public class DonorFragment extends Fragment implements DonationAdapter.OnRVClickListener, SwipeRefreshLayout.OnRefreshListener, HttpResponseListener {


    private RecyclerViewEmptySupport recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private List<DonateInfo> allcases;
    private SearchView searchView;
    private FloatingActionButton fab_addcase;
    SwipeRefreshLayout swipeRefreshLayout;
    DonationAdapter donationAdapter;
    private final int ADD_CASE_REQ_CODE=121;
    private ProgressDialog progressDialog;
    private AlertDialog alertDialog;
    private AlertDialog.Builder abuilder;
   // private StatesRecyclerViewAdapter statesRecyclerViewAdapter;

    private View loadingView;
    private View emptyView;
    private View errorView;

    public static DonorFragment newInstance(int categoryid) {
        DonorFragment fragment = new DonorFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("categoryid", categoryid);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        pageViewModel = new ViewModelProvider(this).get(PageViewModel.class);
//        int index = 1;
//        if (getArguments() != null) {
//            index = getArguments().getInt(ARG_SECTION_NUMBER);
//        }
//        pageViewModel.setIndex(index);
    }
public MutableLiveData<Boolean> hasSub=new MutableLiveData<Boolean>();
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.active_donation_fragment, container, false);
        progressDialog = new ProgressDialog(getContext());
        abuilder=new AlertDialog.Builder(getContext());

      
        searchView=root.findViewById(R.id.srchvw);

        searchView.setQueryHint("Search in active donations");
         searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                donationAdapter.getFilter().filter(newText);
                return true;
            }
        });

swipeRefreshLayout=root.findViewById(R.id.spRefresh);
swipeRefreshLayout.setOnRefreshListener(this);
        swipeRefreshLayout.setColorSchemeResources(R.color.primary,
                android.R.color.holo_green_dark,
                android.R.color.holo_orange_dark,
                android.R.color.holo_blue_dark);
        recyclerView=root.findViewById(R.id.rv_allcases);
        recyclerView.setHasFixedSize(true);

        //((SimpleItemAnimator) Objects.requireNonNull(recyclerView.getItemAnimator())).setSupportsChangeAnimations(false);

        linearLayoutManager=new LinearLayoutManager(getContext());
        allcases=new ArrayList<DonateInfo>();
        //loadingView = getLayoutInflater().inflate(R.layout.view_loading, , false);
        //emptyView = getLayoutInflater().inflate(R.layout.view_empty, recyclerView, false);
        //errorView = getLayoutInflater().inflate(R.layout.view_error, recyclerView, false);
//recyclerView.setItemAnimator(null);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setEmptyView(root.findViewById(R.id.list_empty));
        recyclerView.setHasFixedSize(true);
        donationAdapter=new DonationAdapter(allcases, this);
        //donationAdapter.setHasStableIds(true);
        //statesRecyclerViewAdapter = new StatesRecyclerViewAdapter(donationAdapter, loadingView, emptyView, errorView);

        recyclerView.setAdapter(donationAdapter);

        //statesRecyclerViewAdapter.setState(StatesRecyclerViewAdapter.STATE_EMPTY);

       // loadData();


        //        final TextView textView = root.findViewById(R.id.section_label);
//        pageViewModel.getText().observe(this, new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        return root;
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }
    private void showProgressDialogWithTitle(String title,String substring) {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);
        //Setting Title
        progressDialog.setTitle(title);
        progressDialog.setMessage(substring);
        progressDialog.show();

    }

    // Method to hide/ dismiss Progress bar
    private void hideProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.dismiss();
    }
    private void loadData()
    {
        try{
            ((MainActivity)getActivity()).checkInternet();
        }
        catch (Exception ees)
        {

        }
        int category_id=0;
        if (getArguments() != null) {
            category_id = getArguments().getInt("categoryid");
        }
//        if(user_id==0)
//            return;

        Retrofit retrofit = NetworkClient.getRetrofit();

        GeneralApis generalApis = retrofit.create(GeneralApis.class);

        Call<JsonArray> call = generalApis.loadDonatelist(category_id);
       // Call<JsonArray> call = casesApis.getCases();
        call.enqueue(new Callback<JsonArray>() {
            @Override
            public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                JsonArray res=response.body();
                try {
                    //hideProgressDialogWithTitle();

                    //if(res.size()==0)

                    if(response.code()==200)
                    {
                        allcases.clear();
                        Gson gson=new Gson();
                        DonateInfo[] allcaseinfos= gson.fromJson(res,DonateInfo[].class);
                        List<DonateInfo> listCases = new ArrayList<>(Arrays.asList(allcaseinfos));

                        if(allcaseinfos.length==0) {
                            //donationAdapter.setState(donationAdapter.STATE_NORMAL);
                            allcases.addAll(listCases);

                        }
                        else {
                            //donationAdapter.setState(donationAdapter.STATE_NORMAL);

                            allcases.addAll(listCases);
                       }
                        donationAdapter.notifyDataSetChanged();


//                        abuilder.setMessage("Register Success")
//                                .setCancelable(false)
//                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialogInterface, int i) {
//                                        alertDialog.dismiss();
////                                        Intent intent = new Intent(RegActivity.this, CameraActivity.class);
////                                        startActivity(intent);
//                                    }
//                                });
//                        alertDialog = abuilder.create();
//                        alertDialog.setTitle("Success");
//                        alertDialog.show();






                    }
                    else
                    {
//                        abuilder.setMessage("Register Failed")
//                                .setCancelable(false)
//                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialogInterface, int i) {
//                                        alertDialog.dismiss();
//                                    }
//                                });
//                        alertDialog=abuilder.create();
//                        alertDialog.setTitle("Failed");
//                        alertDialog.show();
                        //btnUpload.setVisibility(View.VISIBLE);
//Toast.makeText(MainActivity.this,"Match Found",Toast.LENGTH_LONG).show();
                    }
                    //Log.d("response_xx",message);

                } catch (Exception e) {
                    hideProgressDialogWithTitle();
                    try {
                        String reserr = e.getMessage();

                        // btnUpload.setVisibility(View.VISIBLE);
                        //loading.setVisibility(View.GONE);
//                        abuilder.setMessage("Register Failed \n"+reserr)
//                                .setCancelable(false)
//                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialogInterface, int i) {
//                                        alertDialog.dismiss();
//
//                                    }
//                                });
//                        alertDialog = abuilder.create();
//                        alertDialog.setTitle("Failed");
//                        alertDialog.show();
                        //btnUpload.setVisibility(View.VISIBLE);

                        // Toast.makeText(RegActivity.this, res, Toast.LENGTH_LONG).show();

                    } catch (Exception ex) {

                    }
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonArray> call, Throwable t) {
                try{
                    ((MainActivity)getActivity()).checkInternetWithException(t);
                }
                catch (Exception ees)
                {

                }
                hideProgressDialogWithTitle();
//                abuilder.setMessage("Error \n HTTP Exception "+t.getLocalizedMessage())
//                        .setCancelable(false)
//                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                alertDialog.dismiss();
//
//                            }
//                        });
//                alertDialog = abuilder.create();
//                alertDialog.setTitle("Failed");
//                alertDialog.show();


            }
        });
    }

    @Override
    public void onResume() {
        loadData();

        //checkSubscription();
//        boolean b=SingleTonClass.getInstance().isNotifOpen();
//        if(!SingleTonClass.getInstance().isNotifOpen()) {
            //loadData();
            //SingleTonClass.getInstance().setNotifOpen(false);
//        }
//        else
//         SingleTonClass.getInstance().setNotifOpen(false);
//        boolean hasSubscription=false;
//        try{
//            hasSubscription=SingleTonClass.getInstance().isHasSubscription();
//        }
//        catch (Exception e)
//        {
//
//        }
//        fab_addcase.setVisibility(hasSubscription?View.VISIBLE:View.GONE);
        super.onResume();
    }

    @Override
    public void onRVItemClick(int position) {
        DonateInfo caseInfo=allcases.get(position);
        Intent intent=new Intent(getContext(),DonationDetailActivity.class);
        intent.putExtra("flag",1);
        intent.putExtra("donateinfo",caseInfo);
        getActivity().startActivityForResult(intent,999);
        //Toast.makeText(getContext(),caseInfo.getCase_no(),Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onRefresh() {

        loadData();

        //fab_addcase.setVisibility(hasSubscription?View.VISIBLE:View.GONE);
        //donationAdapter.updateData(allcases);

        if(swipeRefreshLayout!=null)
        swipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void onResponse(Object response) {
        Response retrofitresponse= (Response) response;
        JsonObject jsonObject=(JsonObject)retrofitresponse.body();
//String result=res.body().toString();
        Gson gson=new Gson();


    }

    @Override
    public void onError(String message) {

    }
}