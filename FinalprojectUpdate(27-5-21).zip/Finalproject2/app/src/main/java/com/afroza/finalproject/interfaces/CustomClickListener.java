package com.afroza.finalproject.interfaces;

public interface CustomClickListener {
    void onClick(String input);
}
