package com.afroza.finalproject.networktask;

public class StaticClass {
   // public static final String BASE_URL="http://192.168.31.118/casediary/public/";
    public static final String BASE_URL="http://facedetection.casediary.com.bd/";
    public static final String CATEGORY_IMAGE_URL="http://facedetection.casediary.com.bd/uploads/testimages/category/";
    public static final String PROFILE_IMAGE_URL="http://facedetection.casediary.com.bd/uploads/testimages/user/";
    public static final String REACHABILITY_TEST_URL = "http://facedetection.casediary.com.bd/";
    public static final String GOOGLE = "https://www.google.com/";
    public static final String SHAREPREF="sohayappafroza";

    //public static final String LOGIN_URL="api/user/login";
}
