package com.afroza.finalproject.helper;


public class RequestHelper {

//    public static void retrofitRequest(String classname,String interfacename) throws ClassNotFoundException {
//        Class classTemp = Class.forName(classname);
//
//    }






}
