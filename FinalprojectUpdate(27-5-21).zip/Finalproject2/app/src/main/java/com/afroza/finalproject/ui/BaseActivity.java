package com.afroza.finalproject.ui;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.graphics.Color;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;


import com.afroza.finalproject.R;
import com.afroza.finalproject.helper.AppHelper;
import com.afroza.finalproject.networktask.NetworkUtil;
import com.afroza.finalproject.networktask.NoConnectivityException;
import com.github.pwittchen.reactivenetwork.library.rx2.ReactiveNetwork;
import com.google.android.material.snackbar.Snackbar;

import java.net.UnknownHostException;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

//import com.github.pwittchen.reactivenetwork.library.rx2.internet.observing.InternetObservingSettings;
//import com.github.pwittchen.reactivenetwork.library.rx2.internet.observing.strategy.SocketInternetObservingStrategy;

//import io.reactivex.android.schedulers.AndroidSchedulers;
//import io.reactivex.disposables.Disposable;
//import io.reactivex.schedulers.Schedulers;


public class BaseActivity extends AppCompatActivity {


    private static final String TAG = BaseActivity.class.getSimpleName();
    private BroadcastReceiver br;
    public boolean isInternetAvailable = false;

    Disposable networkDisposable, internetDisposable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    protected void onResume() {
        super.onResume();
        //SocketEventServiceImpl.getInstance().setEventListener(this);
        networkReachAbilityCheck();

        //checkInternet();
    }
public void checkInternet()
{
    try {
        AppHelper.hasInternetConnection().subscribe((hasInternet) -> {
            String msg = "";
            if (hasInternet) {
                hideSnakeBar();

            } else {
                showSnack();

                //
            }

            //Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        });
    }
    catch (Exception e)
    {}
}

    private void showSnack()
    {
        if(snackbar==null) {

            showSnackBar(getString(R.string.msg_not_available), R.color.red, Snackbar.LENGTH_INDEFINITE);

        }
        else
        {
            boolean b=snackbar.isShown();
            if(!b) {
                snackbar.show();
            }
            else
            {
                snackbar=null;
                showSnack();
            }
                    //showSnackBar(getString(R.string.msg_not_available), R.color.red, Snackbar.LENGTH_INDEFINITE);


                //showSnackBar(getString(R.string.msg_not_available), R.color.red, Snackbar.LENGTH_INDEFINITE);

        }
    }
    public void checkInternetWithException(Throwable t)
    {

        if(t instanceof UnknownHostException || t instanceof NoConnectivityException) {

           showSnack();
        }

    }
    @Override
    protected void onPause() {
        super.onPause();
        safelyDispose(networkDisposable, internetDisposable);
    }

    @Override
    protected void onDestroy() {
        safelyDispose(networkDisposable, internetDisposable);
        super.onDestroy();
    }

    private void safelyDispose(Disposable... disposables) {
        for (Disposable subscription : disposables) {
            if (subscription != null && !subscription.isDisposed()) {
                subscription.dispose();
            }
        }
    }

    public boolean networkReachAbilityCheck() {
if(!NetworkUtil.isNetworkConnected(this))
{
    showSnack();
    return false;
}
else {
    networkDisposable = ReactiveNetwork.observeNetworkConnectivity(getApplicationContext())
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(

                    connectivity -> {
                        Log.d(TAG, connectivity.toString());
                        final NetworkInfo.State state = connectivity.state();
                        final String name = connectivity.typeName();

                        if (state == NetworkInfo.State.CONNECTED) {
//                                if(NetworkUtil.internetIsConnected())
//                                {
//                                    isInternetAvailable = true;
//                                    hideSnakeBar();
//                                }
//                                else
//                                {
//                                    isInternetAvailable = false;
//                                    showSnackBar(getString(R.string.msg_not_available), R.color.red, Snackbar.LENGTH_INDEFINITE);
//                                }
                            checkInternet();
//                                InternetObservingSettings settings = InternetObservingSettings
//                                        .host(StaticClass.REACHABILITY_TEST_URL)
//                                        .strategy(new SocketInternetObservingStrategy())
//                                        .build();
//
//
//                                internetDisposable = ReactiveNetwork.observeInternetConnectivity(settings)
//                                        .subscribeOn(Schedulers.io())
//                                        .observeOn(AndroidSchedulers.mainThread())
//                                        .subscribe(
//                                                isConnected -> {
//                                                    isInternetAvailable = isConnected;
//
//                                                    if (isConnected) {
//                                                        //showSnackBar( getString(R.string.msg_not_available), R.color.green, Snackbar.LENGTH_LONG);
//                                                        hideSnakeBar();
//                                                        //internet connection back call cached api request
//                                                        //cacheQueCall();
//
//                                                    } else {
//                                                        showSnackBar(getString(R.string.msg_not_available), R.color.red, Snackbar.LENGTH_INDEFINITE);
//                                                    }
//                                                }
//
//                                        );

                        } else {
                            isInternetAvailable = false;
                            showSnack();
                        }


                    },

                    throwable -> {
                        showSnack();
                    });
}
return true;
    }


    private View getRootView() {
        final ViewGroup contentViewGroup = (ViewGroup) findViewById(android.R.id.content);
        View rootView = null;

        if (contentViewGroup != null)
            rootView = contentViewGroup.getChildAt(0);

        if (rootView == null)
            rootView = getWindow().getDecorView().getRootView();

        return rootView;
    }

    protected void showSnackBarWithOK(@StringRes int res) {
        final View rootView = getRootView();
        if (rootView != null) {
            final Snackbar snackbar = Snackbar.make(getRootView(), res, Snackbar.LENGTH_INDEFINITE);
            snackbar.setAction("OK", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    snackbar.dismiss();
                }
            });

            snackbar.show();
        }
    }

    protected void showSnackBarWithOK(String res) {
        final View rootView = getRootView();
        if (rootView != null) {
            final Snackbar snackbar = Snackbar.make(getRootView(), res, Snackbar.LENGTH_INDEFINITE);
            snackbar.setAction("OK", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    snackbar.dismiss();
                }
            });

            snackbar.show();
        }
    }

    protected void showSnackBar(@StringRes int res) {

        final View rootView = getRootView();
        if (rootView != null)
            Snackbar.make(rootView, res, Snackbar.LENGTH_LONG).show();
    }

    Snackbar snackbar;

    protected void showSnackBar(String res, int color, int duration) {
        try {
//if(snackbar!=null)
//{
//    snackbar.show();
//}
//else {
            final View rootView = getRootView();
            if (rootView != null) {
                snackbar = Snackbar.make(rootView, res, duration);
                snackbar.setAction("Retry", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //snackbar.dismiss();
                         networkReachAbilityCheck();

                    }
                });
                snackbar.setActionTextColor(Color.WHITE);
                snackbar.getView().setBackgroundColor(getResources().getColor(color));
                Snackbar.SnackbarLayout layout = (Snackbar.SnackbarLayout) snackbar.getView();

                snackbar.show();
//    }

            }
        }
        catch (Exception e)
        {

        }
    }

    protected void hideSnakeBar() {
        try {
            if (snackbar != null) snackbar.dismiss();
        }
        catch (Exception e)
        {

        }
    }


//    public void logout(DataAuth dataAuth) {
//
//
//        Auth.getInstance().logout(dataAuth.getUserId(), dataAuth.getToken(), new ResponseAuth.Logout() {
//            @Override
//            public void logoutResponse(DataResponse response) {
//                if (User.getInstance().logout(new PrefManager(), getApplicationContext())) {
//
//                    //disconnect socket connection
//                    SocketEventServiceImpl.getInstance().disconnect();
//
//                    safelyDispose(networkDisposable, internetDisposable);
//
//                    gotoLogin();
//                }
//            }
//
//            @Override
//            public void errorResponse(DataResponse<?> error) {
//                Log.d(TAG, "errorResponse: " + error.getMessage());
//                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
//                //Cache API Call as request fail
//                new CacheHandler().logout(Auth.getInstance().getLogin());
//                gotoLogin();
//
//            }
//        });
//    }
//
//    public void logoutCache(DataAuth dataAuth) {
//
//        Auth.getInstance().setLogin(dataAuth);
//
//        Auth.getInstance().logout(dataAuth.getUserId(), dataAuth.getToken(), new ResponseAuth.Logout() {
//            @Override
//            public void logoutResponse(DataResponse response) {
//                if (User.getInstance().logout(new PrefManager(), getApplicationContext())) {
//
//                    //disconnect socket connection
//                    SocketEventServiceImpl.getInstance().disconnect();
//
//                    safelyDispose(networkDisposable, internetDisposable);
//
//                    try {
//                        FirebaseInstanceId.getInstance().deleteInstanceId();
//                        Log.d(TAG, "logoutResponse:  FirebaseInstanceId.getInstance().deleteInstanceId()");
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//
//                    Log.d(TAG, "logoutCache logoutResponse: " + response.getMessage());
//
//                }
//            }
//
//            @Override
//            public void errorResponse(DataResponse<?> error) {
//                Log.d(TAG, "logoutCache errorResponse: " + error.getMessage());
//                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
//                //Cache API Call as request fail
//                new CacheHandler().logout(Auth.getInstance().getLogin());
//
//            }
//        });
//    }
//
//    private void gotoLogin() {
//        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
//        finish();
//    }
//
//    private void cacheQueCall() {
//        new CacheHandler().handleLogout(new CacheHandler.LogoutHandlerListener() {
//            @Override
//            public void callback(DataAuth dataAuth) {
//                logoutCache(dataAuth);
//            }
//        });
//
//    }

    public Dialog progressDialog;

//    public void showProgress(String msg) {
//
//        if (progressDialog == null) {
//            /*progressDialog= new ProgressDialog(getContext());
//            progressDialog.setTitle("Signup in progress...");
//            progressDialog.setCancelable(false);*/
//
//
//            progressDialog = new Dialog(this);
//            progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//            progressDialog.setContentView(R.layout.layout_progress);
//            progressDialog.setTitle("");
//
//            TextView text = (TextView) progressDialog.findViewById(R.id.text);
//            if (TextUtils.isEmpty(msg)) text.setVisibility(View.GONE);
//            text.setText(msg);
//        }
//
//        progressDialog.show();
//    }
//
//    public void hideProgress() {
//        if (progressDialog != null)
//            progressDialog.dismiss();
//    }




    //private TripOparetionDialog tripOparetionDialog;




}
