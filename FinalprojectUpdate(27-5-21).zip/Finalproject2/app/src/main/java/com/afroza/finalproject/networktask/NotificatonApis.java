package com.afroza.finalproject.networktask;

import com.google.gson.JsonArray;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface NotificatonApis {
    @GET("api/getunreadmessages/{user_id}")
    Call<JsonArray> getAllUnreadMessages(
                                    @Path("user_id") int user_id
                                   );
    @GET("api/getunreadmessagescount/{user_id}")
    Call<JsonArray> getAllUnreadMessagesCount(
            @Path("user_id") int user_id
    );

    @POST("api/notification/updatestatus/{notif_id}")
    Call<String> setNotifStatus(
            @Path("notif_id") String notif_id
    );

    @POST("api/notification/allstatus/{user_id}")
    Call<JsonArray> setUserAllNotifStatus(
            @Path("user_id") int user_id
    );


}
