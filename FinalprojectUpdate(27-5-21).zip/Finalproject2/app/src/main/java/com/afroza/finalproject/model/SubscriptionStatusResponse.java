package com.afroza.finalproject.model;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Keep
public class SubscriptionStatusResponse implements Serializable {
    @SerializedName("willshow")
    private int willshow;
    @SerializedName("info")
    private String info;
    @SerializedName("canclose")
    private int canclose;
    @SerializedName("infoicon")
    private int infoicon;
    @SerializedName("add")
    private int can_add;
    @SerializedName("edit")
    private int can_edit;
    @SerializedName("view")
    private int can_view;
    @SerializedName("sub_msg")
    private String sub_msg;
    @SerializedName("expired")
    private String expired;
    public SubscriptionStatusResponse() {
    }

    public SubscriptionStatusResponse(int willshow, String info, int canclose, int infoicon, int can_add, int can_edit, int can_view, String sub_msg, String expired) {
        this.willshow = willshow;
        this.info = info;
        this.canclose = canclose;
        this.infoicon = infoicon;
        this.can_add = can_add;
        this.can_edit = can_edit;
        this.can_view = can_view;
        this.sub_msg = sub_msg;
        this.expired = expired;
    }

    public int getWillshow() {
        return willshow;
    }

    public void setWillshow(int willshow) {
        this.willshow = willshow;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getCanclose() {
        return canclose;
    }

    public void setCanclose(int canclose) {
        this.canclose = canclose;
    }

    public int getInfoicon() {
        return infoicon;
    }

    public void setInfoicon(int infoicon) {
        this.infoicon = infoicon;
    }

    public int getCan_add() {
        return can_add;
    }

    public void setCan_add(int can_add) {
        this.can_add = can_add;
    }

    public int getCan_edit() {
        return can_edit;
    }

    public void setCan_edit(int can_edit) {
        this.can_edit = can_edit;
    }

    public int getCan_view() {
        return can_view;
    }

    public void setCan_view(int can_view) {
        this.can_view = can_view;
    }

    public String getSub_msg() {
        return sub_msg;
    }

    public void setSub_msg(String sub_msg) {
        this.sub_msg = sub_msg;
    }

    public String getExpired() {
        return expired;
    }

    public void setExpired(String expired) {
        this.expired = expired;
    }

    @Override
    public String toString() {
        return "SubscriptionStatusResponse{" +
                "willshow=" + willshow +
                ", info='" + info + '\'' +
                ", canclose=" + canclose +
                ", infoicon=" + infoicon +
                ", can_add=" + can_add +
                ", can_edit=" + can_edit +
                ", can_view=" + can_view +
                ", sub_msg='" + sub_msg + '\'' +
                ", expired='" + expired + '\'' +
                '}';
    }
}
