package com.afroza.finalproject.adapters;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.IntDef;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.afroza.finalproject.R;
import com.afroza.finalproject.helper.AppHelper;
import com.afroza.finalproject.model.DonateInfo;
import com.github.marlonlom.utilities.timeago.TimeAgo;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;

public class DonationAdapter extends RecyclerView.Adapter<DonationAdapter.ViewHolder> implements Filterable {
    private List<DonateInfo> alldonations=new ArrayList<>();
    private List<DonateInfo> alldonationsold=new ArrayList<>();
    OnRVClickListener onRVClickListener;
    private static final int VIEW_TYPE_EMPTY_LIST_PLACEHOLDER = 0;
    private static final int VIEW_TYPE_OBJECT_VIEW = 1;
    private  View vLoadingView;
    private  View vEmptyView;
    private  View vErrorView;

    @Override
    public Filter getFilter() {
        alldonations=alldonationsold;
        return new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults=new FilterResults();
                if(charSequence==null || charSequence.length()==0)
                {
                    filterResults.count=alldonationsold.size();
                    filterResults.values=alldonationsold;
                }
                else
                {
                    String searchstring=charSequence.toString().toLowerCase();
                    List<DonateInfo> searchcases=new ArrayList<>();
                    for (DonateInfo caseInfo:
                            alldonations) {
                        try {

                            if (    (caseInfo.getDonate_date()!=null &&
                                    caseInfo.getCategory_name().toLowerCase().contains(searchstring))
                                    ||
                                    (caseInfo.getType_name()!=null &&
                                    caseInfo.getDescription().toLowerCase().contains(searchstring))
                                    ||
                                    (caseInfo.getDonor_name()!=null &&
                                    caseInfo.getUser_location().toLowerCase().contains(searchstring))
                                    )
                            {
                                searchcases.add(caseInfo);
                            }
                        }
                        catch (Exception e)
                        {
                            String err=e.getMessage();
                        }
                    }
                    filterResults.count=searchcases.size();
                    filterResults.values=searchcases;
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                alldonations=(List<DonateInfo>)filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @IntDef({STATE_NORMAL, STATE_LOADING, STATE_EMPTY, STATE_ERROR})
    @Retention(RetentionPolicy.SOURCE)
    public @interface State {
    }
    public static final int STATE_NORMAL = 0;
    public static final int STATE_LOADING = 1;
    public static final int STATE_EMPTY = 2;
    public static final int STATE_ERROR = 3;

    public static final int TYPE_LOADING = 1000;
    public static final int TYPE_EMPTY = 1001;
    public static final int TYPE_ERROR = 1002;
    @State
    private int state = STATE_NORMAL;

    public DonationAdapter(List<DonateInfo> alldonations, OnRVClickListener onRVClickListener
                           //  , View loadingView, View emptyView, View errorView
    ) {
        this.alldonations = alldonations;
        this.alldonationsold = alldonations;
        this.onRVClickListener=onRVClickListener;
//        this.vLoadingView = loadingView;
//        this.vEmptyView = emptyView;
//        this.vErrorView = errorView;
    }
    @State
    public int getState() {
        return state;
    }

    public void setState(@State int state) {
        this.state = state;
        //getWrappedAdapter().notifyDataSetChanged();
        notifyDataSetChanged();

    }




    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=null;
//        switch (state) {
//            case STATE_LOADING:
//                view= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_loading,parent,false);
//                return new ViewHolder(view,onRVClickListener,viewType);
//            case STATE_EMPTY:
//                view= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_empty,parent,false);
//                return new ViewHolder(view,onRVClickListener,viewType);
//            case STATE_ERROR:
//                view= LayoutInflater.from(parent.getContext()).inflate(R.layout.view_error,parent,false);
//                return new ViewHolder(view,onRVClickListener,viewType);
//        }
       // return null;


//        switch (viewType)
//        {
//            case VIEW_TYPE_EMPTY_LIST_PLACEHOLDER:
//            {
//                view= LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_empty_layout,parent,false);
//
//            }
//            case VIEW_TYPE_OBJECT_VIEW:
//            {
                view= LayoutInflater.from(parent.getContext()).inflate(R.layout.donation_card_layout,parent,false);

//            }
//            default:
//            {
//                view= LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_empty_layout,parent,false);
//
//            }
//        }
        return new ViewHolder(view,onRVClickListener,0);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
//        switch (state) {
//            case STATE_LOADING:
//                onBindLoadingViewHolder(holder, position);
//                break;
//            case STATE_EMPTY:
//                onBindEmptyViewHolder(holder, position);
//                break;
//            case STATE_ERROR:
//                onBindErrorViewHolder(holder, position);
//                break;
//            default:

                DonateInfo donateInfo = alldonations.get(position);
        long timeInMillis= AppHelper.milliseconds(donateInfo.getCreated_date());
        String timeAgo = TimeAgo.using(timeInMillis+6*60*60*1000);
                holder.catName.setText(donateInfo.getCategory_name());
                String title="";
                if(TextUtils.isEmpty(donateInfo.getDonate_title()))
                    title="No Title";
                else
                    title=donateInfo.getDonate_title();
                holder.donatetitle.setText(title);
                holder.timeAgo.setText(timeAgo);
        if(donateInfo.isHide_name()==1)
        {
            holder.donorName.setText("Anonymous");
        }
        else {
            holder.donorName.setText(donateInfo.getDonor_name());
        }
                holder.donorLocation.setText(donateInfo.getUser_location());
//                break;
//        }

    }
    public void onBindErrorViewHolder(RecyclerView.ViewHolder holder, int position) {
    }

    public void onBindEmptyViewHolder(RecyclerView.ViewHolder holder, int position) {
    }

    public void onBindLoadingViewHolder(RecyclerView.ViewHolder holder, int position) {
    }
    @Override
    public int getItemCount() {
        switch (state) {
            case STATE_LOADING:
            case STATE_EMPTY:
            case STATE_ERROR:
                return 1;
        }
        return alldonations.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView catName,timeAgo,donorName,donorLocation,donatetitle;
        ImageView profileImg;
        OnRVClickListener onRVClickListener;
        public ViewHolder(@NonNull View itemView,OnRVClickListener onRVClickListener,int viewType) {
            super(itemView);
            if(viewType==0) {
                catName=itemView.findViewById(R.id.catName);
                timeAgo=itemView.findViewById(R.id.timeAgo);
                donorName=itemView.findViewById(R.id.donorName);
                donorLocation=itemView.findViewById(R.id.donorLocation);
                donatetitle=itemView.findViewById(R.id.donateTitle);
                this.onRVClickListener = onRVClickListener;
                itemView.setOnClickListener(this);
            }
        }

        @Override
        public void onClick(View view) {
onRVClickListener.onRVItemClick(getAdapterPosition());
        }
    }
    public interface OnRVClickListener{
        void onRVItemClick(int position);
    }

//    @Override
//    public int getItemViewType(int position) {
//        switch (state) {
//            case STATE_LOADING:
//                return TYPE_LOADING;
//            case STATE_EMPTY:
//                return TYPE_EMPTY;
//            case STATE_ERROR:
//                return TYPE_ERROR;
//            default:
//                return super.getItemViewType(position);
//        }
//    }

//    @Override
//    public long getItemId(int position) {
//        if(alldonations.size()>0)
//        return Integer.parseInt(alldonations.get(position).getCase_id());
//        else
//            return 0;
//    }
}
