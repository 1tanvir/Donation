package com.afroza.finalproject.networktask;

import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface UserApis {
    @FormUrlEncoded
    @POST("api/user/login/test")
    Call<JsonObject> checkLogin(
                                    @Field("username") String username,
                                    @Field("password") String password
                                   );

    @FormUrlEncoded
    @POST("api/user/isValid")
    Call<JsonObject> isValid(
            @Field("user_id") int user_id,

            @Field("token") String token
    );

    @FormUrlEncoded
    @POST("api/user/logout")
    Call<String> logout(
            @Field("user_id") int user_id,
            @Field("token") String token
    );


    @FormUrlEncoded
    @POST("api/user/register/test")
    Call<JsonObject> register(
                             @Field("full_name") String full_name,
                           //  @Field("lawyerid") String lawyerid,
                             @Field("user_email") String user_email,
                             @Field("user_mobile") String user_mobile,
                            // @Field("useraddress") String useraddress,
                             @Field("password") String password
    );

    @FormUrlEncoded
    @POST("api/user/generateOTP")
    Call<JsonObject> getOTP(
            @Field("mobileno") String mobileno
            //,
           // @Field("lawyer_id") String lawyer_id
    );

    @FormUrlEncoded
    @POST("api/user/sendCode")
    Call<JsonObject> sendCodeGeneral(
            @Field("verif_on") String verif_on
    );

    @FormUrlEncoded
    @POST("api/user/email/sendCode")
    Call<JsonObject> sendEmailCode(
            @Field("name") String name,
            @Field("email") String email,
            @Field("user_id") int user_id
    );

    @FormUrlEncoded
    @POST("api/user/mobile/verify")
    Call<JsonObject> mobileVerify(

            @Field("mobileno") String mobileno,
            @Field("verif_code") String verif_code
    );

    @FormUrlEncoded
    @POST("api/user/verify")
    Call<JsonObject> generalVerify(

            @Field("verif_on") String verif_on,
            @Field("verif_code") String verif_code
    );

    @FormUrlEncoded
    @POST("api/user/email/verify")
    Call<JsonObject> emailVerify(

            @Field("user_id") int user_id,
            @Field("email") String email,
            @Field("verif_code") String verif_code
    );


    @FormUrlEncoded
    @POST("api/user/password/reset")
    Call<JsonObject> resetPass(

            @Field("user_id") int user_id,
            @Field("password") String password
    );


    @FormUrlEncoded
    @POST("api/user/email/verify")
    Call<String> mobileEmail(
            @Field("user_id") int user_id,
            @Field("verif_code") String verif_code
    );

    @FormUrlEncoded
    @POST("api/user/saveSettings")
    Call<String> saveSettings(
            @Field("user_id") int user_id,
            @Field("issms") int lawyerid,
            @Field("isemail") int useremail,
            @Field("country") int country,
            @Field("district") int district,
            @Field("thana") int thana,
            @Field("postal") String password,
            @Field("address") String address,
            @Field("contact") String contact,
            @Field("legal") String legal
    );



    @FormUrlEncoded
    @POST("api/user/updateProfile")
    Call<JsonObject> updateProfile(
            @Field("user_id") int userid,
            @Field("full_name") String username,
            @Field("user_email") String useremail,
            @Field("user_mobile") String usermobile

    );

    @FormUrlEncoded
    @POST("api/user/updatePassword")
    Call<JsonObject> updatePassword(
            @Field("user_id") int userid,
            @Field("oldpass") String oldpass,
            @Field("newpass") String newpass

    );
    @FormUrlEncoded
    @POST("api/user/photo")
    Call<String> uploadImage(@Field("base64image") String base64image,
                                    @Field("user_id") int user_id);


    @GET("api/user/photo/{user_id}")
    Call<String> loadImage(
                             @Path("user_id") int user_id);

    @GET("api/user/email/isVerified/{user_id}/{email}")
    Call<String> isEmailVerified(
            @Path("user_id") int user_id,
            @Path("email") String email);



}
