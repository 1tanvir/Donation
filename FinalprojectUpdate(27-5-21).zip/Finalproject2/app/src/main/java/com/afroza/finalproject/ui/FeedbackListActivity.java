package com.afroza.finalproject.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


import com.afroza.finalproject.R;
import com.afroza.finalproject.adapters.FeedbackAdapter;
import com.afroza.finalproject.model.Feedback;
import com.afroza.finalproject.networktask.GeneralApis;
import com.afroza.finalproject.networktask.NetworkClient;
import com.afroza.finalproject.utils.LoginHelper;
import com.afroza.finalproject.utils.RecyclerViewEmptySupport;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.JsonArray;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;

public class FeedbackListActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener {
    private LinearLayoutManager linearLayoutManager;
    private List<Feedback> notifications;
    private FeedbackAdapter notifactionAdaper;
    private RecyclerViewEmptySupport recyclerView;
    private BroadcastReceiver receiver;
    private SearchView searchView;
    SwipeRefreshLayout swipeRefreshLayout;
    FloatingActionButton addBtn;
int notifCount=0;
    private GeneralApis generalApis;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_feedback_list);
        toolbar=findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("");
        searchView=findViewById(R.id.srchvw);
        addBtn=findViewById(R.id.addBtn);
        searchView.setQueryHint("Search in notifications");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                notifactionAdaper.getFilter().filter(newText);
                return true;
            }
        });
addBtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent=new Intent(FeedbackListActivity.this,FeedbackActivity.class);
        startActivity(intent);
    }
});
        swipeRefreshLayout=findViewById(R.id.spRefresh);
        swipeRefreshLayout.setOnRefreshListener(this);
        swipeRefreshLayout.setColorSchemeResources(R.color.primary,
                android.R.color.holo_green_dark,
                android.R.color.holo_orange_dark,
                android.R.color.holo_blue_dark);

        linearLayoutManager=new LinearLayoutManager(this);
        notifications=new ArrayList<Feedback>();

        //loadingView = getLayoutInflater().inflate(R.layout.view_loading, , false);
        //emptyView = getLayoutInflater().inflate(R.layout.view_empty, recyclerView, false);
        //errorView = getLayoutInflater().inflate(R.layout.view_error, recyclerView, false);
//recyclerView.setItemAnimator(null);
        recyclerView=findViewById(R.id.notif_list);
        recyclerView.setHasFixedSize(true);
        linearLayoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setEmptyView(findViewById(R.id.notif_list_empty));
        notifactionAdaper=new FeedbackAdapter(notifications);
        //casesAdapter.setHasStableIds(true);
        //statesRecyclerViewAdapter = new StatesRecyclerViewAdapter(casesAdapter, loadingView, emptyView, errorView);

        recyclerView.setAdapter(notifactionAdaper);
        getallUnreadMessages();

        //statesRecyclerViewAdapter.setState(StatesRecyclerViewAdapter.STATE_EMPTY);

        //sampleData();

    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }

    @Override
    protected void onDestroy() {


        super.onDestroy();
    }

    private void setupBadge() {
    }
    private void getallUnreadMessages()
    {

        int user_id= LoginHelper.getCurrentUser()!=null?LoginHelper.getCurrentUser().getUser_id():0;

        if(user_id==0)return;
        Retrofit retrofit = NetworkClient.getRetrofit();

        generalApis = retrofit.create(GeneralApis.class);

        Call<JsonArray> call = generalApis.getFeedbacks();
        // Call<JsonArray> call = casesApis.getCases();
        call.enqueue(new Callback<JsonArray>() {
            @Override
            public void onResponse(Call<JsonArray> call, retrofit2.Response<JsonArray> response) {
                JsonArray res=response.body();
                try {

                    if(response.code()==200)
                    {
                        //notifications.clear();
                        notifications.clear();
                        Gson gson=new Gson();
                        Feedback[] allNotificationInfos= gson.fromJson(res,Feedback[].class);
                        List<Feedback> list = new ArrayList<>(Arrays.asList(allNotificationInfos));
                        if(allNotificationInfos.length==0) {

                            notifCount=0;
                            setupBadge();
                            //notifications.addAll(list);
                            //casesAdapter.setState(casesAdapter.STATE_NORMAL);
                            //notifications.addAll(listCases);

                        }
                        else {
                            notifCount=allNotificationInfos.length;
                            setupBadge();
                            notifications.addAll(list);

                            //casesAdapter.setState(casesAdapter.STATE_NORMAL);

                            //notifications.addAll(listCases);
                        }
                        notifactionAdaper.notifyDataSetChanged();
                    }
                    else
                    {
//
                    };

                    //Log.d("response_xx",message);

                } catch (Exception e) {
                    //hideProgressDialogWithTitle();
                    try {
                        String reserr = e.getMessage();

                    } catch (Exception ex) {

                    }
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonArray> call, Throwable t) {
                checkInternetWithException(t);
            }
        });

    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.trans_right_in,R.anim.trans_right_out);

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    @Override
    protected void onResume() {
        getallUnreadMessages();
        super.onResume();
    }



    @Override
    public void onRefresh() {
        try {
            getallUnreadMessages();
        }
        catch (Exception e)
        {}
        if(swipeRefreshLayout!=null)
            swipeRefreshLayout.setRefreshing(false);
    }
}