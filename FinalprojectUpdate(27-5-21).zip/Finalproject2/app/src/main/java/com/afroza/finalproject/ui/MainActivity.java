package com.afroza.finalproject.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.afroza.finalproject.R;
import com.afroza.finalproject.networktask.StaticClass;
import com.afroza.finalproject.utils.LoginHelper;
import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends BaseActivity implements NavigationView.OnNavigationItemSelectedListener {
ViewPager viewPager;
TabLayout tabLayout;
    NavigationView navigationView;
    ActionBarDrawerToggle actionBarDrawerToggle;
    //private AppBarConfiguration mAppBarConfiguration;
    DrawerLayout drawerLayout;
    CircleImageView userimage;
    TextView username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MainPagerAdapter mainPagerAdapter = new MainPagerAdapter(this, getSupportFragmentManager());
        viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(mainPagerAdapter);
        tabLayout = findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
        drawerLayout=findViewById(R.id.drawer_layout);
        setTabIcons();

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerview=navigationView.getHeaderView(0);
        userimage=headerview.findViewById(R.id.userimage);
        username=headerview.findViewById(R.id.username);

        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        actionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
loadDeafults();

    }
    private void loadDeafults()
    {
        try{
            String user_name=LoginHelper.getCurrentUser().getUser_name();
            username.setText(user_name);
            String imgsrc=LoginHelper.getCurrentUser().getUser_image();
            Glide.with(this).load(StaticClass.PROFILE_IMAGE_URL+imgsrc).error(R.drawable.ic_profile_svg).into(userimage);
        }
        catch (Exception e)
        {

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDeafults();
    }

    private void setTabIcons()
    {

            int[] tabIcons = {

                    //R.drawable.ic_baseline_feedback_24,
                    R.drawable.donatee,
                    R.drawable.ic_baseline_explore_24,
                    R.drawable.mydonate
                    //R.drawable.ic_profile_svg

            };

            for(int i=0; i<tabLayout.getTabCount(); i++){
                if(tabLayout.getTabAt(i) != null){
                    tabLayout.getTabAt(i).setIcon(tabIcons[i]);

                }
            }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.nav_profile: {
                Intent intent=new Intent(MainActivity.this,ProfileActivity.class);
                intent.putExtra("editmode",0);
                startActivity(intent);

                break;
            }
            case R.id.nav_donation: {


                break;
            }
            case R.id.nav_feedback: {
                Intent intent=new Intent(MainActivity.this,FeedbackListActivity.class);

                startActivity(intent);

                break;
            }

        }
        //close navigation drawer
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}